# Handoff: Our Leadership (bio listing + bio detail)

## Overview

Two designed surfaces for Mechanicsburg Christian Church's `bio` content type:

1. **Listing** — `/who-we-are/our-leadership`, driven by the `mcc_leadership` view.
   A photo-forward directory of the 20 people who lead the church, grouped or
   filtered by the `mcc_leadership_structure` taxonomy.
2. **Detail** — the individual `node--bio` full view.

The job both pages do is **reassurance and wayfinding**: who runs this ministry,
who do I talk to about grief care, is there a face I recognize. Neither page is a
biography reader — only 3 of 20 people have prose, and the layouts are built so
that the other 17 still produce a complete-looking page.

## About the design files

The two `.dc.html` files in this bundle are **design references created in HTML** —
prototypes showing intended look and behavior. They are not production code and
should not be copied into the theme.

The task is to **recreate these designs as Twig templates in `mcc_theme`** using
the theme's existing patterns: the token CSS in
`web/themes/custom/mcc_theme/css/tokens/`, the existing `mcc-*` component classes,
and the `caresphere_theme` Canvas SDCs where they fit. The person card should be
built as a sibling of `mcc-event-card` — same card idiom, same radius, same
hairline border — not as a new visual language.

Concretely, expect to create:

- `node--bio.html.twig` (full view) — the detail page
- `node--bio--teaser.html.twig` — the person card used by the listing
- `views-view--mcc-leadership.html.twig` (+ unformatted-summary partial) — the
  listing shell, grouped by `field_ministry_structure`
- `mcc-person-card`, `mcc-people-grid`, `mcc-person-header`, `mcc-role-explainer`
  CSS components

## Fidelity

**High-fidelity.** Colors, typography, spacing, and card geometry are final and
come from the theme's own tokens. Recreate pixel-for-pixel using existing token
variables — every value in the Design tokens section below is already defined in
`css/tokens/`; do not introduce new ones.

Two things are deliberately *not* final:

- **Photography** is represented by drop-target placeholders. Real portraits come
  from `field_bio_pic` through the focal-point image styles (see Assets).
- **Copy** in the "Reach out about" chips and the per-group role explainers is
  drafted, not approved. It is real content the church needs to write once — see
  Content dependencies.

---

## Blocking content dependencies

Two content problems must be resolved before either template can ship. Both are
content work, not template work.

### 1. The title field mixes name and role — must be split

Real titles today: `Brian Hoffman -  Emergency Response Team`,
`Pat Garland - Communications &amp; Women's`, `Alan Martin Finance `, `Jim Garland `.
Inconsistent delimiters, sometimes no delimiter, trailing whitespace.

Both designs render **name** and **role** as separate typographic elements at
different sizes, in different faces. There is no reliable way to split those
strings at render time — `Alan Martin Finance` has no delimiter at all, and a
regex cannot tell "Finance" from a surname.

**Required:** add `field_role` (plain text, single value) to the `bio` type,
migrate the role out of each title by hand across 20 nodes, and normalize each
title to the person's name only. Until that is done the templates should render
the raw title in the name slot and leave the role slot empty — which will look
wrong, correctly signalling the data problem.

### 2. Prose is nearly absent, and the page must not depend on it

`body` is populated for exactly **3 of 20** people (1,268 / 987 / 514 chars). A
fourth node contains the literal string `<p>-</p>` and must be treated as empty —
check for it explicitly:

```twig
{% set has_bio = content.body|render|striptags|trim not in ['', '-'] %}
```

Both templates render the biography section only when `has_bio`, and both fall
back to a **role explainer** — a paragraph describing what elders/deacons/trustees
do, written once per taxonomy term. Store these on the taxonomy term's own
`description` field so the church can edit them without a developer.

---

## Field fill rates (design to these numbers)

| Field | Machine name | Populated | Of 20 |
|---|---|---|---|
| Photo | `field_bio_pic` | 19 | almost all |
| Leadership structure | `field_ministry_structure` (multi) | 20 | all |
| Phone | `field_phone_number` | 14 | most |
| Email | `field_email` | 6 | under a third |
| Biography | `body` | 3 | almost none |
| Attachments | `field_attachments` | 0 | none |

`field_attachments` is unused by every bio. Do not render it. If it is ever used,
it should appear as a plain file list under the biography, not as a primary element.

**Taxonomy distribution:** Ministry Leaders 11, Deacons 6, Elders 3, Trustees 3,
Senior Minister 1 — 24 assignments across 20 people, because four people hold two
roles (Alan Martin, Jon Culbertson, Gary Allen, Jim Garland).

---

## Screen 1 — Listing: Our Leadership

### Purpose

Scan the people who lead the church; find the right one; get to them.

### Layout

Full-width page on `--surface-page`. Content column is
`max-width: var(--container-max)` (1200px), `margin: 0 auto`, side padding
`var(--space-6)`.

Vertical order:

1. **Site header** — existing `mcc-header`. Sticky, `z-index: 50`,
   `background: var(--surface-page)`, `border-bottom: 1px solid var(--border-default)`.
   Inner bar `padding: 14px var(--space-6)`, flex, space-between. Logo 42px tall.
   Nav links 15px `--fw-bold`; the active item is `--color-primary` with a
   `2px solid var(--color-secondary)` bottom border and 2px bottom padding.
2. **Page header band** — `background: var(--neutral-50)`,
   `border-bottom: 1px solid var(--border-default)`,
   `padding: var(--space-12) var(--space-6) var(--space-10)`.
   Breadcrumb (14px, `--text-muted`, ` / ` separators, 20px bottom margin), then a
   flex row, `align-items: flex-end`, `gap: var(--space-10)`, wrapping:
   - Left: eyebrow "Who we are" + `h1` "Our leadership"
   - Right: 17px intro paragraph, `--text-muted`, `max-width: 460px`,
     `text-wrap: pretty`
3. **Featured senior minister** (optional, on by default) — see below
4. **The people** — filtered grid or grouped sections, see below
5. **"Not sure who to ask?" band** — `background: var(--terracotta-900)`,
   `color: var(--text-on-inverse)`, `padding: var(--space-16) var(--space-6)`.
   Flex row, space-between, wrapping. Heading 30px Calistoga; body 16px at
   `opacity: .9`; secondary button "Contact the office" + "or call (765) 325-2772".
6. **Site footer** — existing `mcc-footer`, walnut with the oak texture at
   `opacity: .3` over a `--walnut-900` layer at `opacity: .78`.

### Featured senior minister

The single-person taxonomy group is not rendered as a group of one. It becomes a
horizontal feature card above the grid, and that person is then **excluded from
the grid and from all filter counts** (so "Everyone" reads 19, not 20).

Grid `300px 1fr`, `gap: var(--space-10)`, on `--surface-card` with
`1px solid var(--border-default)`, `border-radius: var(--radius-md)`,
`overflow: hidden`. Photo column `min-height: 400px`, fills. Text column
`padding: var(--space-10) var(--space-10) var(--space-10) 0`, centered vertically,
`max-width: 640px`: eyebrow "Senior minister", 36px Calistoga name, 16px/1.65
summary in `--text-muted`, then two buttons (primary "Read Rod's story",
outline "Get in touch").

### Person card (the core component)

Used in both the grid and the grouped sections. Recreate as `mcc-person-card`,
sibling to `mcc-event-card`.

- Container: `background: var(--surface-card)`,
  `border: 1px solid var(--border-default)`, `border-radius: var(--radius-md)`,
  `overflow: hidden`, `cursor: pointer`
- Hover: `box-shadow: var(--shadow-md)`, `border-color: var(--border-strong)`,
  transition `var(--duration-fast) var(--ease-standard)` on both properties
- Photo well: `aspect-ratio: 3/4`, `background: var(--color-primary-subtle)`,
  image `object-fit: cover`, absolutely positioned to fill
- No-photo state: the same well, centered initials in Calistoga 52px,
  `color: var(--green-700)`, `opacity: .55`. **A monogram, not a silhouette** —
  a generic person icon reads as a broken image on a page of real faces.
- Body: `padding: var(--space-5)`
  - Name: Calistoga 20px, `line-height: 1.2`, `--text-body`, 6px bottom margin
  - Role: Nunito 14px, `line-height: 1.45`, `--text-muted`,
    `min-height: 20px` so cards with an empty role still align
  - Group chips: flex, `gap: 6px`, wrap. Each: 12px `--fw-bold`, `padding: 3px 10px`,
    `border-radius: var(--radius-pill)`, `background: var(--color-primary-subtle)`,
    `color: var(--green-800)`
  - "Read bio →": 13px `--fw-bold` `--text-link`, 14px top margin, **only when
    `has_bio`** — it is the affordance that distinguishes the 3 rich records

Grid: `repeat(4, 1fr)`, `gap: var(--space-8)`.

### Grouping — two modes, both built

The prototype exposes `listingLayout` so the two can be compared side by side.

**`filter` — one flat grid + taxonomy filter chips.** Chip row above the grid:
label "Filter by group" (13px `--fw-bold`, `--tracking-eyebrow`, uppercase,
`--text-muted`), then a chip per term plus "Everyone". Chips are
`border-radius: var(--radius-pill)`, `padding: 8px 16px`, 14px `--fw-bold`,
`1px solid var(--border-strong)`; each carries its count at `opacity: .65`.
Selected chip: `background: var(--color-primary)`, `color: var(--text-on-primary)`.
Row has `padding-bottom: var(--space-8)` and a bottom hairline.

**`grouped` — labeled sections per term.** Sections stack with
`gap: var(--space-20)`. Each header is a flex row, `align-items: flex-end`,
bottom hairline, `padding-bottom: var(--space-5)`, `margin-bottom: var(--space-8)`:
30px Calistoga term name + its description (15px/1.6, `--text-muted`,
`max-width: 620px`) on the left, "6 people" on the right (13px `--fw-bold`,
uppercase, `--tracking-eyebrow`, `--text-faint`).

**The dual-role rule.** Under `grouped`, the four two-group people appear in
**both** sections, each instance carrying a 12px `--text-faint` line reading
"Also serves as Trustee". A closing caption states the rule: "Four people serve in
two groups and appear in both lists." Under `filter` they appear **once** and match
both chips — no duplication, no rule needed.

**Recommendation: ship `filter`.** It handles the dual-role case cleanly, keeps
the lopsided 11/6/3/3 distribution from reading as four sections of wildly
different weight, and gives visitors a direct path. Keep `grouped` available; it
is a template variant, not a rebuild.

---

## Screen 2 — Detail: individual bio

### Purpose

One person: who they are, what to talk to them about, how to reach them, and — if
it exists — their story.

### Should this page exist at all?

Recommended answer: **yes, but do not lean on it.** With 3 bios in 20, most detail
pages are a photo, a role, and a contact form. It earns its place because of the
"Reach out about" chips, the role explainer, and the related-people band — all of
which work with zero prose. The listing's expand-in-place drawer (built in the
listing prototype) is the primary reading experience; the detail page is the
permalink, the shareable URL, and the search result. Build both; expect the drawer
to carry most of the traffic.

### Layout

Header, then a slim breadcrumb strip (`--neutral-50`,
`padding: var(--space-5) var(--space-6)`, bottom hairline) ending in the person's
name.

Main: `max-width: var(--container-max)`,
`padding: var(--space-12) var(--space-6) var(--space-20)`, grid
`340px 1fr`, `gap: var(--space-16)`, `align-items: start`.

**Left rail** — `position: sticky; top: 100px`, flex column, `gap: var(--space-6)`:

- Portrait: `aspect-ratio: 3/4`, `border-radius: var(--radius-md)`,
  `overflow: hidden`, `1px solid var(--border-default)`. Monogram fallback at
  Calistoga 88px, `--green-700`, `opacity: .5`.
- "Serves as" card: `--surface-card`, hairline, `--radius-md`,
  `padding: var(--space-6)`. Eyebrow, then one row per taxonomy term — term name
  as a 16px bold link back to the listing, with a 14px `--text-muted` note beneath
  (the person's role for their primary term, "Also serves in this group" for the
  second). **This is where multi-value `field_ministry_structure` is honored.**
- "← All leadership" link, 15px `--fw-bold`.

**Right column** — `max-width: 680px`:

- Eyebrow: singular term name ("Elder"), 13px `--fw-bold`, `--tracking-eyebrow`,
  uppercase, `--color-secondary`
- `h1`: Calistoga 52px, `line-height: 1.08`, 14px bottom margin
- Role: 20px/1.5 `--text-muted`, `margin-bottom: var(--space-10)`

Then a stack of sections, each `padding: var(--space-8) 0` with
`border-top: 1px solid var(--border-default)`, each led by the same eyebrow style
(16px bottom margin):

1. **Reach out about** — flex, `gap: 10px`, wrapping. Chips: 15px,
   `padding: 8px 16px`, `border-radius: var(--radius-pill)`,
   `1px solid var(--border-strong)`, `background: var(--surface-card)`.
   *This is the single most valuable element on the page* — it is what answers
   "who do I talk to about grief care." It needs a new field (see below).
2. **About {firstName}** — 18px/1.7 paragraphs, 18px bottom margin,
   `text-wrap: pretty`. **Rendered only when `has_bio`.**
3. **What deacons do** — the taxonomy role explainer, same 18px/1.7 type.
   Always rendered. This is what keeps the 17 prose-less pages from looking empty.
4. **Get in touch** — see Contact policy.

**Related band** — `--neutral-50`, top hairline,
`padding: var(--space-16) var(--space-6)`. Header row: 28px Calistoga
"Others serving as deacons" + "See everyone →". Then up to 4 person cards in
`repeat(4, 1fr)`, `gap: var(--space-8)`, same card component as the listing,
rendered as links. Excludes the current person. Hide the whole band if the group
has no other members.

### New field required: "Reach out about"

The chips are not derivable from existing data. Add `field_topics`
(plain text, unlimited, 2–4 values per person) to the `bio` type. This is a small
content task — a phrase or two per person — and it does more for the page's actual
job than 20 biographies would. Suggested starting values are in the prototype's
`PEOPLE` array.

If the field is not added, hide the section entirely; do not substitute the
taxonomy terms, which are already shown in the rail.

---

## Contact policy — an explicit recommendation

14 people have a phone number on file and 6 have an email. **Do not publish them.**

These are personal contact details for named private individuals on a public,
crawlable page. Publishing them exposes the congregation's volunteer leadership to
scraping, spam, and unsolicited contact, and — importantly — none of these 20
people consented to publication when the data was entered into the legacy site.
"It is in the field, so render it" is not consent.

**Recommended (`form`, the prototype default):** each person's "Get in touch"
section is a short message form — name, email or phone, message — that posts to the
church office and is forwarded. Explicit copy sets the expectation:

> Messages go to the church office and are passed straight to {firstName}. We
> don't publish personal phone numbers or email addresses.

Plus a visible fallback: "Or call the office at (765) 325-2772". Implement with
Webform, one form reused across all bios, the target person passed as a hidden
node reference.

**If the church overrules this** (`direct` mode is built so they can see it):
gate it per person on a new `field_publish_contact` boolean, default **off**,
set only after asking each person individually. Never render `field_email` or
`field_phone_number` on the strength of the value merely existing.

**Middle path worth offering:** role-based aliases —
`elders@mechanicsburgchristian.com`, `youth@…` — which survive turnover, need no
per-person consent, and are the better long-term answer regardless.

---

## Interactions & behavior

- **Card click** (listing) → opens the detail drawer. Whole card is the hit target.
- **Drawer**: fixed overlay, `z-index: 100`. Scrim `rgba(0,0,0,.4)`, click to
  close. Panel is right-anchored, `width: 520px`, `max-width: 100%`,
  `background: var(--surface-card)`, `box-shadow: var(--shadow-lg)`,
  `overflow-y: auto`. Close button top-right, 40×40, `--radius-md`, hairline
  border, `&times;` glyph. **Escape closes it** (`keydown` on window).
  In Drupal, either progressively enhance the card link into a drawer or drop the
  drawer and rely on the detail page — the detail page is the no-JS fallback and
  must work on its own.
- **Filter chips**: client-side, no page reload; the grid re-renders in place.
  With 20 items, do not paginate and do not round-trip to the server.
- **Hover**: cards lift to `--shadow-md`; chips take `border-color: var(--color-primary)`;
  nav links go `--color-primary`. All `var(--duration-fast)` (120ms)
  `var(--ease-standard)`.
- **No entrance animations, no scroll choreography.** The brand is low-motion.
- **Responsive** (not built in the prototype, specify at implementation):
  4-up grid → 3-up ≤1100px → 2-up ≤760px → 1-up ≤480px. Detail page rail
  un-sticks and stacks above the content below 900px. Drawer goes full-width
  below 560px.

## State

Listing: `filter` (taxonomy term id or `all`, default `all`) and `selected`
(node id or null, default null). Detail: none — it is a static render.

## Design tokens

Every value below is already defined in `mcc_theme/css/tokens/`. Use the variable,
not the literal.

**Color** — `--color-primary` (forest green `#2f4833`), `--color-primary-subtle`,
`--green-700`, `--green-800`, `--color-secondary` (terracotta `#ae5b33`),
`--terracotta-900`, `--walnut-900` (`#4e3426`), `--oatmeal` (`#e9e3d5`),
`--surface-page`, `--surface-card`, `--neutral-50`, `--text-body`, `--text-muted`,
`--text-faint`, `--text-on-primary`, `--text-on-inverse`, `--text-link`,
`--text-link-hover`, `--border-subtle`, `--border-default`, `--border-strong`.

**Type** — `--font-display` (Calistoga, weight 400 only) for the `h1`, section
headings, person names, and stat numerals. `--font-body` (Nunito) for everything
else. Weights `--fw-medium` / `--fw-bold`. Eyebrows are 13px `--fw-bold`,
`letter-spacing: var(--tracking-eyebrow)` (0.08em), uppercase, `--color-secondary`.
Sizes used: 52 / 48 / 36 / 30 / 28 / 20 / 18 / 17 / 16 / 15 / 14 / 13 / 12px.

**Spacing** — the scale is `--space-1..6, 8, 10, 12, 16, 20, 24, 32`. Note the
gaps: **there is no `--space-7`, `--space-9`, `--space-11`, `--space-14`.**
Referencing one silently kills the entire declaration (CSS drops the whole
shorthand when any var in it is invalid), which is easy to miss in review.

**Radius** — `--radius-sm` 6px (inputs), `--radius-md` 10px (cards, buttons,
drawer), `--radius-pill` 999px (chips).

**Shadow** — `--shadow-sm` (resting, optional), `--shadow-md` (card hover),
`--shadow-lg` (drawer).

**Motion** — `--duration-fast` 120ms, `--ease-standard` `cubic-bezier(.4,0,.2,1)`.

## Assets

- `assets/MCC-logo-horizontal.svg`, `assets/MCC-logo-icon.svg` — the real brand
  marks, already in the theme. Never redraw them.
- `assets/oak-wood.jpg` — footer texture, tiled at 340px, `opacity: .3` over a
  `--walnut-900` layer at `opacity: .78`.
- **Portraits** come from `field_bio_pic` → media image → focal-point image style.
  Migrated focal points cluster at 45–50% horizontal, 35–50% vertical (faces sit
  slightly above center), so the crop is safe at any ratio.
  **Use the 3:4 focal-point styles**, WebP, 225×300 through 720×960 — a 3:4 crop
  gives the grid a calmer rhythm than the legacy 2:3 while keeping more of the
  shoulders than 1:1. Serve `450×600` for cards, `720×960` for the detail rail and
  the featured card, with `srcset`.
  The prototypes use drag-and-drop placeholder wells in place of real photos.
- **Icons**: none are used on either page. If any are added later, the theme's
  Lucide set is the established choice.

## Files in this bundle

- `MCC Leadership.dc.html` — the listing, with both grouping modes, the filter
  chips, the featured minister, and the detail drawer. Tweakable:
  `listingLayout` (filter | grouped), `featureMinister`, `contactPolicy`.
- `MCC Bio Detail.dc.html` — the individual bio page. Tweakable: `person`
  (all 20, for checking edge cases), `contactPolicy`, `showRelated`.
  Worth previewing: **Brian Hoffman** (long bio), **Larry Metzler** (no photo,
  no bio, no contact — the worst case), **Gary Allen** (dual role).
- `support.js`, `image-slot.js` — prototype runtime only. Not part of the design;
  do not port.
- `_ds/` — the design-system token CSS the prototypes load. These are the same
  tokens as `mcc_theme/css/tokens/`; reference the theme's copies, not these.

Open either `.dc.html` directly in a browser.
