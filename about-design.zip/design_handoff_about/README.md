# Handoff: About + Our History (and the level-3 page pattern)

## Overview

Two pages for Mechanicsburg Christian Church (MCC), an independent Christian church in rural Boone
County, Indiana, est. 1840.

1. **About** (`/about`) — the section landing page. Vision and mission, then four cards routing to
   the four About children: **Who we are**, **Our beliefs**, **Our history**, **Our leadership**.
2. **Our history** (`/about/our-history`) — the first fully-built level-3 page. It establishes the
   **sidebar section-navigation layout** that must be used on every page three levels deep or more.

The Our History layout is the template for **Who we are** and **Our beliefs** (not yet designed).
Build the layout once as a reusable page template; those two pages are then content only.

## About the design files

The files in this bundle are **design references created in HTML** — prototypes showing intended look
and behavior, **not production code to copy**. Recreate them in the target codebase using its
established patterns (Drupal theme + blocks, React, etc.). If no environment exists, choose the most
appropriate framework and implement there.

Open `MCC About.dc.html` and `MCC Our History.dc.html` directly in a browser. `support.js`,
`image-slot.js` and `_ds/` are prototype runtime and design-system source — reference for exact
values, don't ship.

## Fidelity

**High fidelity.** Colors, type, spacing, and copy are final.

---

## ⚠ Two things to get right before anything else

### 1. Photo placeholders → a real image block

Both pages use `<image-slot>` elements — a drag-and-drop dev affordance that must **not** ship.
Replace each with the **reusable image block** described in the homepage handoff
(`design_handoff_homepage/README.md`) — same block, same fill/fixed-ratio modes, same grey-JPG
fallback behavior. If that block already exists, just reuse it here.

Fallbacks ship in `placeholders/`: flat grey (`#d6d3cc`), faint hatch, thin frame, centered text
naming the photo, its crop, and its minimum size — legible at thumbnail size so a volunteer editor
knows what to upload without reading docs.

| Page | Slot id | Placeholder | Photo we need | Box |
|---|---|---|---|---|
| About | `about-hero` | `placeholders/about-hero.jpg` (2400×1000) | Church building or grounds, wide. Subject in the **upper half** — the green scrim rises from the bottom ~60%. | Fill, `position:absolute; inset:0`, in a `min-height:440px` section |
| History | `history-gathering` | `placeholders/history-gathering.jpg` (1600×800) | The Gathering Place shelter, ideally in use (meal, reunion, youth event) | `width:100%; height:300px`, radius 10 |
| History | `history-quilts` | `placeholders/history-quilts.jpg` (1600×900) | Congregation quilts on the stone wall behind the pulpit — the signature motif | `width:100%; height:340px`, radius 10 |

### 2. The vision statement needs church sign-off

The **mission statement is verbatim and must not be edited**:
"We walk by faith, embracing all that God desires, reaching the world, through Jesus Christ!"

The church has **no published vision statement**. The vision copy on the About page was written for
this design from the church's own history and ministry record, and the Restoration motto quoted with
it ("no creed but Christ, no law but love, no book but the Bible") is documented. **Flag it for the
elders to approve or replace before launch** — treat it as editable content, not hardcoded copy.

---

## Place names: county, not town

Per the church's direction, prose refers to **Boone County** (and "Boone and Clinton counties" where
regional), never Kirklin or Mechanicsburg-as-a-town. The only exception is the mailing address block,
which needs a deliverable postal line. In this prototype the footer reads "650 W. Horton Road /
Boone County, IN 46050" — confirm with the church whether the postal line should read "Kirklin, IN
46050" for mail and directions accuracy while prose stays county-level.

Note: the existing homepage still says "Years serving Kirklin" — update it for consistency.

---

## Design tokens

Same system as the homepage handoff; values from `_ds/.../tokens/*.css`.

**Bases** — `--green-700` `#2f4833` (primary) · `--terracotta-500` `#ae5b33` · `--walnut-700`
`#4e3426` · `--oatmeal` `#e9e3d5` (page). Scales are `color-mix(in oklch, …)` derivations off these —
keep the derivation, or resolve once and paste computed values if `color-mix` isn't available.

**Aliases used** — `--surface-page: oatmeal` · `--surface-card: white-warm` (oatmeal 35 / white 65) ·
`--color-primary: green-700` · `--color-primary-subtle: green-50` · `--color-secondary:
terracotta-700` · `--text-body: neutral-900` · `--text-muted: neutral-600` · `--text-on-inverse:
oatmeal` · `--text-link: terracotta-700` / hover `terracotta-800` · `--border-subtle: neutral-100` ·
`--border-default: neutral-200` · `--border-primary: green-700`.

**Spacing** 4px scale in rem: `--space-1` .25 … `-4` 1 · `-6` 1.5 · `-8` 2 · `-10` 2.5 · `-12` 3 ·
`-16` 4 · `-24` 6rem. `--container-max: 1200px`.

**Type** — `--font-display` **Calistoga** 400 only (h1 48–52, h2 32–34, card titles 23–26, numerals
24–40); `--font-body` **Nunito** variable (body 15–19/1.6–1.7, eyebrows 13 bold uppercase +
`--tracking-eyebrow`, nav 15 bold, legal 13–14). Italic Nunito only for the mission quote, the
tagline, and pull quotes.

**Radii** 10px (`--radius-md`) cards, buttons, photo tiles; 6px small controls.
**Shadows** `--shadow-sm` on card hover only.
**Motion** 120–180ms `cubic-bezier(.4,0,.2,1)` on color/border/shadow only.

---

## Shared chrome (both pages)

### Header
Sticky `top:0`, `z-index:50`, `--surface-page`, 1px `--border-default` bottom. Inner row 1200px,
`padding:14px var(--space-6)`, flex space-between, `gap:24px`. Logo `MCC-logo-horizontal.svg` 42px,
wrapped in a home link. Nav flex `gap:32px`, Nunito 15 bold, current section ("About") in
`--color-primary`, others `--text-body` → hover primary. Right: primary Button sm "Plan your visit".
**Every nav item and the button need `white-space:nowrap; flex:none`.** Below ~940px collapse nav to
a menu button — do not let the row overflow.

### Footer
`--walnut-900` with `assets/oak-wood.jpg` tiled at `background-size:340px, opacity:.3` under a
`--walnut-900` layer at `opacity:.78`; content `z-index:1`, 1200px,
`padding:var(--space-16) var(--space-6) var(--space-8)`.
Grid `1.4fr repeat(3,1fr)`, `gap:var(--space-8)`. First cell: oatmeal chip (radius 10, `10px 14px`)
with `MCC-logo-icon.svg` 32px + two-line Calistoga 15 wordmark in `--walnut-900`, then italic "We
Love People!" at .85. Columns Visit / About / Connect: headings 14 bold uppercase at .7,
`margin-bottom:16px`; items flex column `gap:10px`, 14px at .85.
**Only real links are anchors** — the street address is plain text; `tel:` and `mailto:` on the
number and email only.
Legal row: flex space-between, wraps, `padding-top:var(--space-8)`, 1px `rgba(255,255,255,.15)` top
rule, two 13px spans at .65: "© 2026 Mechanicsburg Christian Church · Est. 1840 · We Love People!"
and "An independent Christian church in Boone County, Indiana".

---

## Page: About

Level-2 page → **photo hero**. (Level-3 pages get a solid band instead; see the pattern below.)

### Hero
`min-height:440px`, flex `align-items:flex-end`, `overflow:hidden`. Photo fills; scrim above it:
`linear-gradient(0deg, green-950@94% 0%, green-900@55% 62%, green-900@22% 100%)` with
`pointer-events:none`. Content `z-index:1`, 1200px,
`padding:var(--space-16) var(--space-6) var(--space-12)`.
Breadcrumb: flex `gap:10px`, 14px at .8 opacity, `margin-bottom:18px` — "Home › **About**", current
crumb bold and not a link.
H1 Calistoga 52/1.1, `max-width:760px`: "Deep roots in Boone County."
Lede Nunito 19/1.6 at .92, `max-width:620px`.

### Vision & mission
1200px, `padding:var(--space-24) var(--space-6)`, grid `1fr 1fr`, `gap:var(--space-16)`,
`align-items:start`.
**Left:** terracotta eyebrow "Our vision"; h2 Calistoga 32/1.2 "A spiritual home for rural Boone
County."; two 17/1.65 muted paragraphs (the county-anchor paragraph, then the Restoration motto).
**Right:** card — `--surface-card`, 1px `--border-default`, radius 10, `padding:var(--space-10)`.
Eyebrow "Our mission", then the mission verbatim in **italic Nunito 23/1.5** `--text-body`. Below a
1px `--border-subtle` rule (`padding-top:20px`), three rows: flex `gap:12px`, 20px Lucide icon in
`--color-primary` (`book-open`, `droplets`, `heart-handshake`) + 15/1.55 muted text.

### "Four places to start"
`--surface-card` band with 1px `--border-subtle` top and bottom, `padding:var(--space-24) var(--space-6)`.
Centered intro `max-width:620px`, `margin-bottom:var(--space-16)`: eyebrow "Get to know us", h2 34
"Four places to start", 16/1.6 muted lede.
Grid `1fr 1fr`, `gap:var(--space-6)`. **Each card is one whole `<a>`**, not a card with a link inside:
`display:flex; gap:var(--space-6)`, `--surface-page` background, 1px `--border-default`, radius 10,
`padding:var(--space-8)`, `min-height:172px`, `text-decoration:none`; hover → `border-color:
var(--border-primary)` + `--shadow-sm`, no underline.
Inside: 56px `--radius-md` tile in `--color-primary-subtle` with a 26px Lucide icon in
`--color-primary`; then h3 Calistoga 23, 15/1.6 muted description, and a 15 bold `--color-secondary`
CTA line ending in "→".

| Card | Icon | Route | CTA |
|---|---|---|---|
| Who we are | `users` | `/about/who-we-are` | Meet the congregation → |
| Our beliefs | `book-open` | `/about/our-beliefs` | Read what we believe → |
| Our history | `landmark` | `/about/our-history` | Walk through 185 years → |
| Our leadership | `user-round-check` | `/about/our-leadership` | See who serves → |

### "At a glance" (toggleable)
1200px, `padding:var(--space-24) var(--space-6)`. Header row flex space-between `align-items:flex-end`,
wraps: eyebrow "At a glance" + h2 34; right a 16/1.6 muted paragraph `max-width:380px`.
Grid `repeat(4,1fr)`, `gap:var(--space-6)`; card `--surface-card`, 1px border, radius 10,
`padding:var(--space-8)`; value Calistoga 40/1.1 `--color-secondary` **with `white-space:nowrap`**
(the "80–100" entry wraps without it), label 15/1.55 muted.
Values: **1840** founded on woodland deeded for perpetual church use · **80–100** neighbors in
worship on a typical Sunday · **5** buildings on this ground, log cabin to worship center · **$0**
debt carried since March 2020.

### Closing CTA
`--green-900`, `padding:var(--space-24) var(--space-6)`, centered. H2 Calistoga 36 "Come see for
yourself.", 17 body at .9 `max-width:520px`, then flex `gap:16px` centered — secondary Button lg
"Plan your visit" + ghost button (transparent, `1px solid rgba(255,255,255,.7)`, radius 10,
`14px 28px`, 18 bold, hover `rgba(255,255,255,.15)`, `white-space:nowrap`) "Watch a sermon".

---

## Page: Our history — and the level-3 template

**This layout applies to every page three levels deep or more** (`/about/our-history`,
`/about/who-we-are`, `/about/our-beliefs`, `/ministries/<program>`, and so on). Build it as one page
template.

### Level-3 title band (replaces the photo hero)
`--green-900`, `--text-on-inverse`, `padding:var(--space-12) var(--space-6) var(--space-16)`, content
1200px. Breadcrumb flex `gap:10px`, wraps, 14px at .8, `margin-bottom:20px` — "Home › About ›
**Our history**", ancestors are links, current crumb bold text. H1 Calistoga 48/1.1
`max-width:760px`. Lede 18/1.65 at .9, `max-width:640px`.
Level-3 pages deliberately get **no photo hero** — the solid band signals depth and keeps these
pages cheap to author.

### Two-column body
1200px, `padding:var(--space-16) var(--space-6) var(--space-24)`, `display:grid`,
`grid-template-columns:248px 1fr`, `gap:var(--space-16)`, **`align-items:start`** (required for the
sticky sidebar to work).

### Sidebar section navigation
`<aside>` with `position:sticky; top:96px` (header is ~71px; 96 leaves a 25px gap).
- Label "On this page" — 13 bold uppercase `--tracking-eyebrow`, `--text-muted`, `margin-bottom:16px`.
- `<nav>` flex column with `border-left:2px solid var(--border-default)` — one continuous rail.
- Each item: `<a href="#section-id">`, `padding:11px 0 11px 16px`, `margin-left:-2px`,
  `border-left:2px solid transparent`, `min-height:44px`, `display:flex; align-items:center`,
  15/1.4.
  **Resting:** `--text-muted`, `--fw-regular`, transparent rail segment.
  **Active:** `--color-primary` text, `--fw-bold`, rail segment `--color-primary`.
  **Hover:** `--color-primary`, no underline.
- Below: 1px `--border-subtle` rule, `margin-top:var(--space-8)`, then "Elsewhere in About" (same
  eyebrow style) and sibling links to the other three children, 15px, `min-height:32px`, flex column
  `gap:12px`.

**Behavior**
- **Scroll-spy.** Each content section carries `data-hsection` and an `id`. On scroll (passive
  listener or IntersectionObserver), the active section is the **last** section whose
  `getBoundingClientRect().top <= 140`; within 80px of page bottom, force the last section active so
  short trailing sections can still become active. Default to the first section on load.
- **Click** — `preventDefault`, then `window.scrollTo({top: el.getBoundingClientRect().top +
  window.scrollY - 96, behavior:'smooth'})` and set active immediately. **Do not use
  `scrollIntoView`.** Sections also carry `scroll-margin-top:96px` so plain hash navigation and
  deep links land correctly.
- Keep the `href="#id"` on every item — it must work with JS off and be keyboard-focusable.
- The sidebar is generated from the page's own headings/sections, not hand-maintained. In a CMS,
  derive it from the section blocks on the page.

**Responsive**
- ≥1024px: two columns as specified.
- 768–1023px: sidebar collapses to a horizontally scrolling chip row or a `<details>` "On this page"
  disclosure pinned under the header; content goes full width.
- ≤767px: same collapsed nav, single column, h1 ~34px, h2 ~26px, photo blocks ~200–240px tall.
- Never let the sidebar sit in a scroll container with `overflow:hidden` — sticky breaks silently.

### Content sections (7, in order)

Each section: terracotta eyebrow (13 bold uppercase) carrying the date range, h2 Calistoga 32/1.2,
then body at 17/1.7 `--text-body`, `max-width:66ch`, `text-wrap:pretty`. Section spacing
`margin-bottom:var(--space-16)`.

| id | Eyebrow | H2 | Extra element |
|---|---|---|---|
| `beginnings` | 1840 | Cut from this land | Pull quote: `border-left:3px solid var(--color-secondary)`, `padding-left:24px`, italic Nunito 19/1.6 muted, `max-width:60ch` |
| `buildings` | 1840 – 2025 | Five buildings, one congregation | Timeline list (below) |
| `fire` | 1961 – 1962 | Fire, and eleven months | Aside card: `--surface-card`, 1px border, radius 10, `padding:var(--space-8)`, `max-width:66ch`, eyebrow "Saved from the old church" + 16/1.65 muted body |
| `growth` | 1974 – 1985 | Room to teach, room to gather | — |
| `gathering` | 2006 – 2025 | The Gathering Place | `history-gathering` photo block, 300px tall, then a 15/1.6 muted caption |
| `stewardship` | 2006 – 2022 | Debt-free by design | 2×2 stat card grid (below) |
| `heritage` | Today | What we have kept | `history-quilts` photo block, 340px tall |

**Timeline list** — one bordered container: 1px `--border-default`, radius 10, `overflow:hidden`,
`--surface-card`. Each row `display:grid; grid-template-columns:92px 1fr; gap:var(--space-6);
padding:var(--space-6); border-top:1px solid var(--border-subtle)`. Year in Calistoga 24/1.2
`--color-primary`; title Nunito 16 bold; detail 15/1.65 muted. Rows: 1840 original log structure ·
1852 timber frame building · 1912 brick and frame meetinghouse · 1962 rebuilt sanctuary · 1974
educational wing · 1985 worship center · 2015 "The Gathering Place" shelter.

**Stewardship cards** — grid `1fr 1fr`, `gap:var(--space-6)`; card `--surface-card`, 1px border,
radius 10, `padding:var(--space-6)`; value Calistoga 26 `--color-secondary`, title 15 bold, note
14/1.6 muted. Entries: $324,000 land expansion 2006 · $40,000 debt retired March 2020 · $40,000
reserve restored Jan 2022 · 2024–25 cash-funded upgrades.

**Prev/next footer** — flex space-between, wraps, `padding-top:var(--space-8)`, 1px
`--border-default` top rule, two 15 bold links with `min-height:44px`: "← Back to About" and "Our
leadership →". Every level-3 page gets this pair, pointing at its section parent and its next sibling.

### Applying this to Who we are / Our beliefs

Same band, same sidebar, same section rhythm. Suggested sections (content still to be written and
approved):
- **Who we are** — a rural congregation · what a Sunday looks like · how we are governed · who we
  serve in the county · how to get connected.
- **Our beliefs** — the Bible · salvation and grace · baptism by immersion · weekly communion ·
  elder-led autonomy · the Holy Spirit. The Restoration-tradition doctrinal detail in the church's
  own report maps cleanly onto these; each belief is a section with a heading and 1–2 paragraphs, so
  the sidebar reads as a doctrine index.

---

## Interactions & behavior (both pages)

- Header sticky; nothing else scroll-driven except the sidebar scroll-spy. No parallax, no reveals.
- Card hover (About destination cards): border → `--border-primary`, add `--shadow-sm`, no underline.
- Link hover: `--text-link-hover` + underline; nav hover → `--color-primary` no underline.
- Focus: solid brand-color outline ring, never a glow. Sidebar items must show a visible focus ring.
- Tap targets ≥44px — sidebar items, prev/next links, nav, buttons.
- Reduced motion: honour `prefers-reduced-motion` by using instant jumps instead of smooth scroll.

## State

Presentational. Only:
- `activeId` — current scroll-spy section on level-3 pages (default: first section id)
- `showFacts` — boolean, About "At a glance" band (default true). Expose as a block setting, not a
  code branch.

## Assets

| File | Origin | Notes |
|---|---|---|
| `assets/MCC-logo-horizontal.svg` | church-supplied | header, 42px |
| `assets/MCC-logo-icon.svg` | church-supplied | footer chip, 32px |
| `assets/oak-wood.jpg` | crop of a church reference photo | footer texture only, tiled 340px @ .3 — low-res, request higher-res oak before scaling up |
| `assets/sanctuary-quilts.jpg` | 2026 handbook cover crop | real photo, low-res; candidate for `history-quilts` once a better scan exists |
| `placeholders/*.jpg` | generated for this handoff | grey fallbacks for the three photo slots |
| Lucide icons | unpkg CDN, MIT | documented substitution — no brand icon set exists; swap for the codebase's set if it has one |
| Calistoga, Nunito | `_ds/.../assets/fonts/` (OFL) | self-host, don't CDN |

## Content sourcing

All historical, financial, doctrinal, and leadership facts come from the church's own research
document and 2026 handbook: founding 1840, the five buildings with costs and dates, the September
1961 fire, the August 19 1962 dedication, the 1974 wing, the 1985 worship center, the 2006 land
purchase and 2020 debt payoff, the 2015 Gathering Place, the quilt wall, 80–100 weekly worshipers,
and the 2026 elder/deacon/trustee rosters. Verify against the church's records before publishing;
dollar figures and dates are the kind of thing a congregation will notice.

## Files

- `MCC About.dc.html` — the About page design
- `MCC Our History.dc.html` — the Our History page design and the level-3 sidebar pattern
- `placeholders/` — grey photo fallbacks
- `assets/` — logos and textures
- `_ds/mechanicsburg-.../` — design-system tokens (`tokens/*.css`), `styles.css`, component bundle, fonts
- `support.js`, `image-slot.js` — prototype runtime only, do not ship

Related: `design_handoff_homepage/` (homepage + the image block spec) and
`design_handoff_leadership_bios/` (the Our leadership child page).
