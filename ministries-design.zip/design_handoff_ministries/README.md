# Handoff: /ministries listing + ministry detail

Design response to `ministries-handoff-to-design` (captured 2026-07-31). Two designs:

- `MCC Ministries.dc.html` — the listing page, replacing band 3 **and** band 5
- `MCC Ministry Detail.dc.html` — the ministry detail page (Women's, nid 38, as the exemplar),
  which today has no layout at all

The files are **design references in HTML** — intended look and behavior, not production code.
Recreate in Drupal/Canvas using the site's existing patterns. `support.js`, `image-slot.js` and
`_ds/` are prototype runtime and design-system source: reference for exact values, don't ship.

**Fidelity: high.** Colors, type, spacing and layout are final. Copy in the cards is **draft** and
needs church review (see §6).

---

## 1. The four decisions the design makes

Your brief asked for opinions on the open questions. Here they are up front.

**One. The visitor should see all eleven ministries in one list, grouped.** The three-bundle split
(`ministry` 6, `page` 5, `missions` 2) is an implementation detail; a visitor reading
`/ministries/emergency-response` has no idea it's a different content type. So: **convert the five
`page`-bundle ministries to the `ministry` bundle** and let the listing cover them. That kills the
blind spot at the source.

**Two. The pillar band's editorial taxonomy is right, and it should be real.** Worship &
Discipleship / Care & Community / Missions & Outreach is a genuinely good way to sort these. Promote
it from hand-typed Canvas copy into a vocabulary (`mcc_ministry_groups`) with weights, make it the
listing's grouping field, and **delete band 5 entirely** — it exists only as a workaround, and once
the listing covers all eleven it has nothing left to do.

**Three. Cards are typographic + icon, not photographic.** There is no image on any ministry and no
realistic prospect of eleven good ministry photos soon. A typographic card with a small icon tile
reads as deliberate; eleven cards with a stock-photo hole in each reads as unfinished. The two
`missions` partners are the exception — those get a **logo** slot, because `field_logo_image` already
exists and a partner org's logo is a thing that actually exists.

**Four. `field_bio_reference` wins over `field_role`.** Once a ministry points at a bio node, "Led
by" comes from the reference. `field_role` on the person stays as the person's own role line (it's
what the leadership page uses) but is never the source for the ministry's leader. Filling six —
eventually eleven — reference fields is a one-pass content task.

---

## 2. What the design needs from the content model

Ordered by how much the design depends on it. Nothing here is exotic; item 1 is the only true
blocker.

### Blocking

**1. `field_summary`** — `string_long`, single, plain text, ~200 char limit, on `ministry`.
The card dek. `field_content` cannot serve this: 66–274 words of governance prose with no teaser
inside it, and a smart-trim produces *"The responsibilities of the Women's Ministry are: To
administer to the needs of…"* — accurate and useless. `page.field_description` is the precedent;
same shape, same purpose. **Required on the bundle**, because an empty card dek is the one thing that
makes the grid look broken. Draft copy for all eleven is in §6.

### Strongly wanted

**2. `field_ministry_group`** — term reference → new vocabulary `mcc_ministry_groups`, single value,
required. Three terms with weights: Worship & Discipleship (0), Care & Community (1), Missions &
Outreach (2). Each term's `description` becomes the group blurb shown to the right of the group
heading (copy in §4). Weight is the display order. Do not hardcode the groups — adding a fourth has
to work from the admin UI, same rule as `mcc_leadership_structure`.

**3. `field_display_title`** — `string`, single, optional, on `ministry`. Falls back to `title`.
This solves both title problems in one field:

| `title` | `field_display_title` | `field_subtitle` |
|---|---|---|
| C.A.R.E. (Christians Are Reaching Everyone) MINISTRY | C.A.R.E. Ministry | Christians Are Reaching Everyone |
| Women's | Women's Ministry | — |
| Youth | Youth Ministry | Preschool through high school |
| Building & Grounds | — (title is fine) | — |

**4. `field_subtitle`** — `string`, single, optional. The small line under the card title. Carries the
C.A.R.E. expansion and age ranges ("Ages 4–12", "Infants to 4 years"). Optional and frequently empty
by design.

**5. `field_schedule`** — `string`, single, optional. Public-facing, short: "Wednesdays, 6:45–8:00pm",
"Sundays 9:30 & 10:30", "Meets quarterly", "During the sermon". This is **not** the time commitment —
it's the answer to "when could I show up".

**6. `field_time_commitment`** — `string_long`, single, optional. The existing "Time Commitment:"
paragraph, lifted out of `field_content` into its own field so it can be styled as the aside it is,
on the detail page only. Never on a card — it's information for someone already deciding to serve.

**7. Split `field_verse`** into **`field_verse_text`** (`string_long`) + **`field_verse_reference`**
(`string`), **cardinality unlimited, as a paired multi-value** (or a small paragraph/field-collection
type — implementer's call). Women's needs two verses with two references; today both live mashed into
one string with the citations inline. `field_verse_link` stays as-is and is used as the reference's
link when populated. Retire the old `field_verse` after migrating the four values by script.

**8. `field_icon`** — `list_string`, single, with an allowed-values list of Lucide names. Used on
the card tile and nowhere else. Assignments in §5. If you'd rather not add a field, a hardcoded
`nid → icon` map in the theme is acceptable for eleven records, but it will rot the first time
someone adds a ministry.

### Content and data fixes (no build)

**9. Fill `field_bio_reference`** on all eleven — the values are already known, they're sitting in
`field_role` on the bios (§4 table has the mapping).

**10. Clean the migration residue** in `field_content` — `&nbsp;`-only spacer paragraphs, `<p>`
inside `<li>`, Word styling. The empty paragraphs survive as real vertical gaps in rendered output.
Script it; it's a regex pass over six values.

**11. Repoint the one Youth calendar event** from trashed node 1223 to node 8, then purge 1223. Until
that happens, Youth shows zero upcoming dates while its event sits on a deleted node.

**12. Dedupe the aliases** on nodes 8 and 11 — canonical is `/ministries/…`.

---

## 3. The template gap (from §5 of your brief)

Two things do not exist and both pages need them:

- **`canvas.content_template.node.ministry.full`** — the ministry detail page. Model it on
  `canvas.content_template.node.page.full.yml`; the detail design below is what it should map to.
- **`core.entity_view_display.node.ministry.teaser`** — so `views.view.mcc_ministries` stops
  silently falling back to `default` (which is the entire reason the listing renders full-page field
  output with visible field labels).
- Plus **`node--ministry--teaser.html.twig`** handing off to a new SDC, `mcc_theme:mcc-ministry-card`
  — exactly the shape `mcc-person-card` already has. Props below.
- `missions` needs the same pair. `/ministries/missions` also has no `<h1>` today.

**`mcc_theme:mcc-ministry-card` props** (mirroring `mcc-person-card`'s conventions):
`title` (display title or title), `subtitle`, `url`, `summary`, `icon`, `schedule`, `next_date`,
`next_date_url`, `leader_name`, `leader_url`, `variant` (`ministry` | `partner`), plus a `logo` slot
used only by the partner variant. Every one except `title` and `url` must render absent cleanly —
five of the eleven are missing at least one.

---

## 4. Page: /ministries

Bands 1 and 2 of the current page **merge into one green title band**; band 3 becomes the grouped
listing; band 4 (verse) and band 6 (CTA) keep their content and get styling. Band 5 is deleted.

### Chrome
Header and footer are unchanged from the live site — sticky oatmeal header, logo at 44px, nav
(I'm New / About / Ministries / Sermons / Calendar) with the current section in `--color-primary`,
primary "Get Involved" button. Every nav item and the button need `white-space:nowrap; flex:none`;
below ~940px collapse the nav to a menu button. Footer is the wood-texture block as built.

### Title band
`--green-900`, `--text-on-inverse`, `padding:var(--space-12) var(--space-6) var(--space-16)`, content
capped at `--container-max`.
Breadcrumb flex `gap:10px`, 14px at .8 opacity, `margin-bottom:20px` — "Home › **Ministries**".
Then a flex row, space-between, `align-items:flex-end`, wrapping: left column `max-width:640px` with
eyebrow "Serve" (13 bold uppercase, `--tracking-eyebrow`, .75 opacity), h1 Calistoga 48/1.1 "Where
people serve at MCC", and a 18/1.65 lede at .9 opacity. Right: secondary Button lg "Find your place"
→ `/get-involved`.
The h1 takes band 2's copy because band 1's "Our ministries" was doing nothing a breadcrumb doesn't.

### Group header (×3)
`max-width:var(--container-max)`, `padding:var(--space-16) var(--space-6) var(--space-12)`; each group
block `margin-bottom:var(--space-16)`.
Flex row, `align-items:flex-end`, `gap:var(--space-6)`, `margin-bottom:var(--space-8)`:
terracotta eyebrow (13 bold uppercase) + h2 Calistoga 30/1.2 on the left; a `flex:1` 1px
`--border-default` rule with `margin-bottom:9px`; the group blurb on the right, 15/1.55 muted,
`max-width:300px`, `flex:none`.

| Term | Eyebrow | Blurb (term description) |
|---|---|---|
| Worship & Discipleship | Sunday mornings | Everything that happens when the church gathers — for every age in the building. |
| Care & Community | Serving one another | Meals, benevolence, and the practical work of looking after this church and this county. |
| Missions & Outreach | Beyond our walls | Support for gospel work here in Boone County and around the world. |

### Ministry card
Grid `repeat(3,1fr)`, `gap:var(--space-6)`. **The whole card is one `<a>`** — flex column,
`--surface-card`, 1px `--border-default`, radius 10, `padding:var(--space-6)`,
`min-height:212px`, `text-decoration:none`; hover → `border-color:var(--color-primary)` +
`--shadow-sm`, no underline.

1. **Head row** — flex, `gap:14px`, `align-items:flex-start`, `margin-bottom:14px`. 44px tile,
   radius 8, `--color-primary-subtle`, holding a 22px Lucide icon in `--color-primary`. Beside it
   h3 Calistoga 21/1.25, and `field_subtitle` under it at 13/1.4 muted when present.
2. **Dek** — `field_summary`, 15/1.6 `--text-muted`, `margin:0 0 auto` so the meta pins to the
   bottom and cards in a row stay aligned.
3. **Meta footer** — `margin-top:18px`, `padding-top:14px`, 1px `--border-subtle` top,
   `min-height:52px`, flex **column**, `gap:7px`. First row: schedule (13 bold muted, `clock` icon)
   and next date (13 bold `--color-secondary`, `calendar` icon), both `white-space:nowrap`, `gap:14px`.
   Second row: "Led by {name}" at 13 muted. The two rows matter — a single wrapping row broke
   "Led by Pat Garland" mid-name at 3-column width.

**Empty states, all real and all present in the data:**
- No summary (Prayer & Outreach) → the dek renders italic `--neutral-500`: *"Ask about this ministry
  on a Sunday morning — a description is on the way."* Deliberately visible, so the gap prompts the
  fix rather than hiding.
- No schedule / no next date (Worship Service, Youth, ERT, Prayer & Outreach) → the meta row just
  omits them; `min-height` holds the card's shape.
- No leader → second meta row omitted.

**Next date** comes from the reverse reference (`calendar_event.field_related_ministry`), soonest
future event, formatted "Wed, Aug 5". Needs a relationship in the view or a lookup in the card
component — `mcc_core.calendar_month` is the existing precedent. Zero events is normal for a third
of the set; do not render a placeholder date.

### Cards, in order

**Worship & Discipleship** — Worship Service (`church`) · Youth Ministry (`users`) · Sunday School
(`book-open`) · Kids Worship (`music`) · Nursery (`baby`)
**Care & Community** — Women's Ministry (`heart-handshake`) · C.A.R.E. Ministry (`utensils`) ·
Building & Grounds (`hammer`) · Emergency Response Team (`siren`) · Prayer & Outreach (`hand-heart`)
**Missions & Outreach** — Missions (`globe`), then the two partner cards

Within a group, order is the view's sort. Alphabetical is wrong here — "Building & Grounds" leading
the whole page is exactly the current bug. Either add `field_weight` (`integer`, sort ascending then
title) or accept the order above as the intended editorial sequence and set weights once.

**Leader mapping** (from `field_role` on the bios, for filling `field_bio_reference`):
Youth → Maria Weidman · Women's → Pat Garland · C.A.R.E. → Jane Mohler · Building & Grounds → John
Weidman · ERT → Brian Hoffman · Prayer & Outreach → Aaron Lucas · Missions → Kerry Dull.
Worship Service, Sunday School, Kids Worship and Nursery have no leader recorded — Robin Lynn
(Music & Worship) and Ellen Bailey (Education) are the likely answers but the church should confirm
rather than us inferring it.

### Partner card (`missions` nodes, `variant="partner"`)
Same footprint and grid cell as a ministry card, but **1px dashed** `--border-default` and
`--surface-page` background — visibly a different kind of thing without a separate band. Head row
carries a 44px logo (`field_logo_image` through the existing responsive-image system) instead of the
icon tile, an 11px terracotta "Partner" eyebrow, and the title at Calistoga 19. Footer row is the
outbound domain from `field_missions_website` with an `external-link` icon.
Placing them in the same grid as the Missions card is load-bearing: Missions is the only ministry in
its group, and alone in a 3-column grid it left a two-thirds-empty row.
Both `field_logo_image` and `field_missions_website` are empty today — placeholders ship in
`placeholders/` (`partner-hanging-rock.jpg`, `partner-love-inc.jpg`), wired as the block's fallback
image exactly like the homepage image block. Without a website value, omit the footer row.

### Verse band
`--surface-card`, 1px `--border-subtle` top and bottom, `padding:var(--space-20) var(--space-6)`,
centered, `max-width:820px`. Terracotta eyebrow "Ephesians 4:11–13" (the reference), then the verse
as Calistoga 32/1.3 in `--color-primary`, then the trailing clause at 16/1.6 muted.
Note the inversion vs. today: reference is the eyebrow, verse is the display type. Content unchanged.

### CTA band
`--terracotta-900`, `padding:var(--space-20) var(--space-6)`, centered. H2 Calistoga 34 "Find where
you fit", 17 at .9 opacity `max-width:520px`, then flex `gap:16px` centered: a solid `--oatmeal`
button with `--walnut-900` text "Get involved", and a ghost button (transparent, `1px solid
rgba(255,255,255,.7)`, radius 10, `14px 28px`, 18 bold, hover `rgba(255,255,255,.15)`) "Give".
On a terracotta band the standard secondary button would be terracotta-on-terracotta, which is why
the primary action is oatmeal here.

### Responsive
≥1024px three columns. 768–1023px two columns; group header wraps, blurb drops below the heading and
the rule collapses. ≤767px one column; h1 ~34px, group h2 ~24px; the meta footer keeps its two rows.

---

## 5. Page: ministry detail (`/ministries/womens`)

The design is generic — Women's is the exemplar because it has the most data (54 events, two verses,
a leader, and the worst of the migration residue).

### Title band
Same green band as the listing. Breadcrumb "Home › Ministries › **Women's Ministry**".
Eyebrow = the **group name** ("Care & Community"), linking the page back to its group.
H1 Calistoga 48/1.1 = display title. Lede 18/1.65 at .9 opacity `max-width:620px` = `field_summary` —
the same sentence as the card, deliberately, so the click is confirmed rather than restated.
Then a meta row, flex `gap:var(--space-6)`, wrapping, 15px at .9: `clock` + `field_schedule` ·
`repeat` + cadence · `user-round` + "Led by {name}". Each element omitted when empty.

### Body: two columns
`max-width:var(--container-max)`, `padding:var(--space-16) var(--space-6) var(--space-20)`, grid
`1fr 320px`, `gap:var(--space-16)`, **`align-items:start`** (required for the sticky rail).

**Main column** (`min-width:0`):
1. **Opening paragraph** — 19/1.7, `max-width:64ch`, `text-wrap:pretty`. This is new copy: a
   visitor-facing rewrite of the first line of `field_content`. See §6.
2. **"What this ministry does"** — h2 Calistoga 28/1.2, then the responsibilities as a flex column,
   `gap:16px`, each row flex `gap:14px` with an 18px `check` icon in `--color-primary` and 17/1.65
   body. This is where `field_content`'s bulleted duty list belongs: it *is* useful, just not as a
   teaser and not as an undifferentiated wall. The four Women's bullets are the migrated ones,
   lightly copy-edited from imperative fragments ("To offer opportunities…") into sentences.
3. **Time commitment** — `field_time_commitment` in a card: `--surface-card`, 1px
   `--border-default`, radius 10, `padding:var(--space-8)`, `max-width:64ch`, terracotta eyebrow
   "Time commitment", 16/1.65 muted body. Visibly secondary, because it addresses a different reader.
4. **Upcoming dates** — h2 28 with "See the full calendar →" pushed right (flex space-between,
   `align-items:baseline`, wraps), 14px padding and a 1px `--border-default` rule under the row.
   Then up to 3 event rows: flex, `align-items:center`, `gap:var(--space-6)`, `--surface-card`,
   1px border, radius 10, `padding:var(--space-5) var(--space-6)`, `min-height:76px`. A 62px centered
   date column (12px uppercase terracotta month over Calistoga 28 `--color-primary` day), a 1px
   `--border-subtle` vertical divider (`align-self:stretch`), then Calistoga 19 title and 14 muted
   "Weekday · time · location". Whole row is a link to the event.
   **Omit the entire section when the ministry has no future events** — don't render an empty
   "Upcoming dates" heading. Worship Service and Youth will hit this today.

**Sidebar** — `position:sticky; top:96px`, flex column, `gap:var(--space-6)`. Two cards:

*Led by* — `--surface-card`, 1px border, radius 10, `padding:var(--space-6)`. Muted eyebrow "Led by",
then a person row: 64×80 portrait at radius 8 (`field_bio_pic` through media view mode `3_4_medium`),
with the **`mcc-monogram` initials fallback** — same component, same rules as the leadership page;
the prototype shows the monogram state. Beside it Calistoga 19 name, 14/1.45 muted `field_role`, and
a 14 bold "Read bio →" to the bio node. Below a 1px `--border-subtle` rule: the office-routing
sentence at 14/1.6 muted, a full-width primary "Get in touch" button, and "Or call the office at
(765) 325-2772" at 13px with a `tel:` anchor.
**Reuse the bio page's contact pattern exactly** — the form routes through the office. Never surface
`field_email` or `field_phone_number`; `field_publish_contact` is off for everybody and the design
must not create a second path around that consent gate.
When `field_bio_reference` is empty, replace the whole card with the office contact block alone
(no empty person row, no "Led by" heading).

*Also in {group}* — muted eyebrow, then sibling ministries in the same group as a flex column,
`gap:2px`; each a link row, flex `gap:12px`, `min-height:44px`, 15px, with its 17px Lucide icon in
`--color-primary`. Excludes the current page. This is the level-2 counterpart to the section-nav
sidebar from the About handoff.

**Note on the sidebar rule from `design_handoff_about/README.md`:** ministry detail is level 2, so it
gets *this* metadata rail, not the scroll-spy "On this page" nav. The level-3 children
(`/ministries/worship-service/kids-worship`, `/nursery`, `/sunday-school`) still get the scroll-spy
sidebar per that handoff — unchanged. If those get converted to the `ministry` bundle per decision
one, they become level 2 and switch to this rail; that's the intended behavior, and it's the one
consequence of the conversion worth flagging.

### Scripture band
`--surface-card`, 1px `--border-subtle` top and bottom, `padding:var(--space-20) var(--space-6)`,
centered, `max-width:820px`. Terracotta eyebrow "Theme scripture". Then, per verse pair: verse text
Calistoga 27/1.4 in `--color-primary`, reference 15 bold muted under it. **Second and subsequent
verses render smaller** — italic Nunito 17/1.7 muted with the same bold reference — so a two-verse
node reads as primary + supporting rather than two competing display blocks. This is why the field
needs to be a repeating pair.
Wrap the reference in `field_verse_link` when populated. Omit the whole band when there's no verse
(Worship Service, Youth).

### CTA band
`--terracotta-900`, same treatment as the listing. Headline and body are **per-ministry copy** — the
Women's version is "Come to a Wednesday" with the no-sign-up reassurance. Oatmeal "Get involved"
button + ghost "All ministries" link. If per-ministry CTA copy is too much content upkeep, fall back
to a generic "Find where you fit" band; a new `field_cta_heading`/`field_cta_body` pair is the
alternative but I'd rather not add two more fields for it.

---

## 6. Copy: what's draft, and what still needs rewriting

**Every `field_summary` in the prototype is draft copy I wrote** from the existing bodies, the 2026
handbook, and the church's own voice. It's accurate as far as the source goes, but the church should
approve all eleven. They're short enough to review in one sitting:

| Ministry | Draft summary |
|---|---|
| Worship Service | Sunday School at 9:30 and worship at 10:30 — blended music, communion every week, and plain preaching. |
| Youth Ministry | Sunday classes, monthly Freedom Rides, camp at Hanging Rock, and VBS each summer. |
| Sunday School | School of the Word: classes for every age and stage, infant through adult. |
| Kids Worship | Children head downstairs during the sermon for songs, prayer, and an age-appropriate lesson. |
| Nursery | Two nurseries during worship — one for toddlers, one for 18 months and younger. |
| Women's Ministry | Bible study on Wednesday evenings, retreats, and friendship for women of the church and community. |
| C.A.R.E. Ministry | Funeral dinners, meals for families after an illness or a new baby, and our Veterans Day event. |
| Building & Grounds | Work days, mowing, repairs, and the upkeep that keeps a 185-year-old property in good order. |
| Emergency Response Team | A trained team ready to help neighbors after storms, fires, and other emergencies in the county. |
| Prayer & Outreach | *(none — ships as the empty state)* |
| Missions | Hanging Rock camps, Love INC, Purdue Campus House, and benevolence for neighbors in need. |

**The larger copy problem your brief named is real and this design does not solve it.** Four of the
six `ministry` bodies are internal governance documents; two address a visitor. The design *contains*
that split — governance prose now lives under "What this ministry does" and in the time-commitment
card, where a job description is the right register — so the four don't read wrong any more. But the
opening visitor-facing paragraph on each detail page is **new copy that doesn't exist yet**. Eleven
paragraphs, one per ministry. The Women's one is written; the other ten are a content task, and worth
scheduling as one because the pages are thin without them.

Prayer & Outreach and Emergency Response have **no body at all** (0 words). ERT has a draft summary;
Prayer & Outreach ships as the visible empty state.

Per the About handoff: prose says **Boone County**, not Kirklin. The postal address in the footer
still needs the church's call on "Kirklin, IN 46050" for mail accuracy.

---

## 7. Interactions, tokens, and the traps

**Interactions.** Header sticky; sidebar sticky; nothing else scroll-driven. Card hover → primary
border + `--shadow-sm`, no underline. Link hover → `--text-link-hover` + underline. Focus: solid
brand outline ring, never a glow. All transitions 120–180ms `cubic-bezier(.4,0,.2,1)` on
color/border/shadow only. Tap targets ≥44px — card rows, sidebar links, event rows, buttons.

**Tokens.** Same system as the homepage and About handoffs: `--green-700` `#2f4833`,
`--terracotta-500` `#ae5b33`, `--walnut-700` `#4e3426`, `--oatmeal` `#e9e3d5`; scales derived with
`color-mix`. Calistoga display-only (h1 48, h2 28–30, card titles 19–21, numerals 28); Nunito
everything else (body 15–19/1.6–1.7, eyebrows 13 bold uppercase + `--tracking-eyebrow`, meta 13–14).
Radius 10 cards / 8 icon tiles. `--container-max` 1200px.

**Your brief's traps, applied here.** Band colour comes from `mcc-landing-bands.css` keyed to
`section_id` — do not use the `backgroundcolor` prop's inverted `bg-*` classes. The listing needs
three new `section_id`s (or one, with the groups rendered inside it). Derive colours with
`color-mix(in oklab, …)`, never `in oklch` — worth repeating because the design-system tokens
themselves ship as `oklch` and copying that syntax into new theme CSS will drift these warm hues
toward rose. Don't write selectors against `data-component-id` for `button` / `section-intro` /
`card-icon` — they never emit it. Check the finished pages **logged in**: `.contextual-region` gets
`position: relative` and becomes the containing block for absolutely positioned children, which is
what collapsed the bio portraits to 0px for editors — the ministry card's icon tile and the partner
logo are both safely static, but the responsive-image wrappers inside the logo slot are not, so
verify that one authenticated. And any ministry-card component that renders a person has to be told
which context it's in, the same way `_mcc_theme_leadership_cards()` passes the term in — the "Led by"
person may serve in two groups.

All content and structure changes belong in an idempotent `scripts/` file alongside
`scripts/ministries-structure.php`, not in a manual admin pass.

## 8. Files

- `MCC Ministries.dc.html` — listing design
- `MCC Ministry Detail.dc.html` — ministry detail design (Women's)
- `placeholders/` — grey fallbacks for the two partner logos
- `assets/` — logos and the footer wood texture
- `_ds/mechanicsburg-.../` — design-system tokens (`tokens/*.css`), `styles.css`, component bundle, fonts
- `support.js`, `image-slot.js` — prototype runtime only, do not ship

Related handoffs: `design_handoff_homepage/` (the reusable image block spec — the partner logo slot
reuses it), `design_handoff_about/` (chrome, the level-3 sidebar pattern, the county naming rule),
`design_handoff_leadership_bios/` (the bio card, monogram, and office-routed contact pattern this
page's sidebar reuses).
