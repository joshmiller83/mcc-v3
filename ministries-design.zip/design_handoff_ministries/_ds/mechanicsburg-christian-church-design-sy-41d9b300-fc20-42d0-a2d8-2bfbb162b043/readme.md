# Mechanicsburg Christian Church — Design System

## About

Mechanicsburg Christian Church ("MCC") is a congregation established in 1840 in Kirklin, Indiana, operating under the tagline **"We Love People!"** and the mission statement **"We walk by faith, embracing all that God desires, reaching the world, through Jesus Christ!"**. The brand is built around a single wordmark: a cross rising from an open Bible, paired with a bold serif nameplate and a friendly italic tagline.

**Contact & location:** 650 W. Horton Road, Kirklin, IN 46050 · (765) 325-2772 · mechanicsburgchristian.com · mechanicsburgsecretary@gmail.com · active on Facebook.

**Schedule:** Sunday School 9:30–10:15am (classes for infant through adult, plus a Sunday School Youth class and a Nursery class), Worship Service 10:30am (Sanctuary, with Youth Church and Toddler Church running alongside). Women's Bible Study meets Wednesdays 6:45–8:00pm. Highway 52 Youth Group (pre-school through high school, led by Maria Weidman) meets the second Sunday after church, lunch provided. Closures are posted on Channel 13, Facebook, and the One Call Now system.

**2026 leadership:** Rod Nielsen, Interim Minister. Elders: Brian Hoffman (Chairman), Mike Smith (Co-Chairman), Tom Dull, Aaron Lucas, Joe Durham. Deacons: Alan Martin, Bob Kline, Jon Culbertson, Doug Ladika, Gary Allen, Jim Garland, John Weidman, Kipper Freeman, Larry Metzler.

**History:** Founded in 1840 when a small group of men cut logs and built the congregation's first church on donated woodland; the current (fifth) worship center dates to 1962 with a 1984–85 addition, and the congregation built "The Gathering Place" picnic shelter in 2015 for its 175th anniversary. A recurring, distinctive visual signature: hand-made quilts from the congregation displayed across the stone sanctuary wall behind the pulpit.

**Sources provided:**
- `uploads/MCC-logo-horizontal.svg`, `MCC-logo-icon.svg`, `MCC-logo-vector.svg` — the only ground-truth brand marks.
- `uploads/Calistoga/` — Calistoga (Google Font), used for the wordmark and all display type.
- `uploads/Nunito/` — Nunito variable font (+ italic), used for the tagline and all body/UI type.
- `uploads/IMG_1388.jpeg` — 2026 Monthly & Ministry Handbook cover: photo collage, contact info, mission statement (a crop of the sanctuary/quilts photo is saved to `assets/photos/sanctuary-quilts.jpg`).
- `uploads/IMG_1389.jpeg` — Mechanicsburg Christian Church History (1840–2025).
- `uploads/IMG_1390.jpeg` — Ministries, schedule, cancellation policy, and 2026 leadership/board rosters.
- Verbal brand direction from the user: *"We use a dark green and dark blue as a primary color. Generally we keep things very simple. Our roots are deep and our designs are practical."*

**Color update (supersedes the verbal direction above):** the user later supplied a specific reference palette — Forest Green (matte), Warm Terracotta, Oatmeal, and Deep Walnut — and asked to adopt it wholesale, dropping dark blue entirely. Terracotta is now the secondary brand color, Oatmeal is the page background, and Deep Walnut anchors the dark/ink end of the neutral scale, and doubles as a wood-grain texture used sparingly for footers/dividers (see Visual foundations below).

No product codebase, Figma file, or existing website was attached, so this is a **from-scratch, brand-guidelines-only** design system: the color system, type scale, spacing, and full component inventory (Button, Input, Select, Checkbox, Radio, Switch, Card, Badge, Tag, Tabs, Dialog, Toast, Tooltip, IconButton) were authored to match the brand direction, not reverse-engineered from an existing UI. The `ui_kits/website/` kit is an original, practical church-website recreation built from those primitives and now uses the real schedule, leadership, and contact facts above — not a copy of an existing site.

If a real MCC website, app, or Figma file exists, attach it and this system should be revised to match it exactly.

## Content fundamentals

**Voice:** warm, plain-spoken, welcoming. MCC speaks like a neighbor, not an institution. The tagline "We Love People!" is the whole ethos — short, declarative, a little exclamatory, never salesy.

- **Person:** second person, direct address. "You're welcome here," not "Guests are welcome." First person plural ("we") for the church speaking about itself: "We gather every Sunday," "We'd love to meet you."
- **Casing:** sentence case for body copy and buttons ("Plan your visit", not "Plan Your Visit"). Title case is reserved for the wordmark and page titles only.
- **Punctuation:** short sentences. One exclamation point is fine for genuine warmth ("We Love People!") — don't stack them, and don't reach for one on every line. Serial/Oxford comma.
- **Emoji:** never. This is a traditional, 180+ year old congregation — warmth comes from word choice, not iconography.
- **Vocabulary:** plain English over churchy jargon where possible. Say "gather," "welcome," "community," "serve" rather than denominational insider terms. When a term is needed (sermon, worship, giving), use it plainly without over-explaining.
- **Numbers/dates:** the founding year (1840) is a recurring credibility marker — "Est. 1840" appears near the logo. Use it sparingly elsewhere as a footnote of heritage, not a headline.

**Example copy:**
- Hero: "You're welcome here." / "Join us this Sunday — everyone belongs."
- Nav/CTA: "Plan your visit", "Watch a sermon", "Give", "Find your group"
- Footer: "Mechanicsburg Christian Church · Est. 1840 · We Love People!"
- Mission statement (use verbatim, sparingly, as a closing/about statement — not a headline): "We walk by faith, embracing all that God desires, reaching the world, through Jesus Christ!"

## Visual foundations

**Color.** Four reference colors, sampled directly from the user's palette image: **Forest Green** (`#2f4833`, matte, primary), **Warm Terracotta** (`#ae5b33`, secondary — replaces the earlier dark blue), **Oatmeal** (`#e9e3d5`, the page background), and **Deep Walnut** (`#4e3426`, the dark/ink end of the neutral scale, and a literal wood texture — see below). Full tint/shade scales for green, terracotta, and the oatmeal-to-walnut neutral ramp live in `tokens/colors.css`, generated with `color-mix(in oklch, …)` off these four exact base values so every step stays true to the reference. No blue remains anywhere in the system.

**Type.** Two typefaces, used strictly by role, mirroring the logo exactly:
- **Calistoga** (serif, slab-like, single weight 400) — display only: hero headlines, section titles, pull quotes. Never body copy, never UI labels. It's heavy and a little rustic — it carries the "deep roots" feeling.
- **Nunito** (rounded sans, variable 200–1000, has italic) — everything else: body copy, nav, buttons, forms, captions. Its rounded terminals keep the brand approachable next to Calistoga's weight. Italic Nunito is reserved for taglines/quote attributions, echoing the logo's italic tagline treatment.

**Spacing & layout.** A plain 4px-based scale (`--space-1` … `--space-32`). Layouts are simple, centered, single-column-first — no asymmetric magazine grids. Max content width 1200px. This is a "practical" brand: generous whitespace over decoration.

**Backgrounds.** Solid colors only for sections — Oatmeal for the page, Forest Green or Warm Terracotta for banner/CTA sections, a warm off-white for cards. The one exception is the Deep Walnut **wood-grain texture** (`assets/textures/oak-wood.jpg`, cropped from the user's own reference photo): used tiled, with a dark walnut overlay, for footers and section-divider bands only — never as a full-page background, and never at full opacity/uncropped (it's a small reference crop; ask for higher-res oak photography before using it any larger). No gradients, no patterns beyond that one wood texture, no photographic full-bleed hero treatments authored here (real photography should be supplied by the church; until then, use placeholders). No decorative illustration style has been established — don't invent one.

**Corner radii.** Modest and consistent: 6px (small controls, inputs, badges), 10px (cards, buttons, dialogs), pill (999px) only for tags/badges/switches. Nothing sharp (0px), nothing very rounded (24px+) — this is a "practical," not playful or luxury, brand.

**Shadows.** Very restrained — a soft, low-contrast green-tinted shadow at three sizes (sm/md/lg), used only to lift cards, dialogs, and dropdowns off the page. No inner shadows, no colored glows.

**Borders.** 1px hairlines in neutral tones are the default separator (nav, table rows, input fields) rather than shadow-only cards. Primary buttons and focus rings use a solid brand-color outline, not a glow.

**Animation.** Minimal and functional: standard-ease (`cubic-bezier(.4,0,.2,1)`) fades/color transitions at 120–180ms for hover/press/open states. No bounce, no spring, no parallax, no scroll-triggered choreography — this is a practical, low-motion brand.

**Hover / press states.** Hover on filled (primary) surfaces lightens one step (e.g. `--green-800` → `--green-700`) for a gentle "lift"; hover on light/outline surfaces adds a subtle tinted background. Press/active moves one step further and drops any shadow, reading as "pressed in." Disabled: desaturate to neutral-300/400 with reduced opacity, never colored-but-faded.

**Transparency & blur.** Essentially unused. The one exception is a subtle scrim (black at ~40% opacity) behind modal dialogs. No frosted-glass/backdrop-blur panels — too trend-driven for this brand.

**Imagery.** Real reference photos are now available (`assets/photos/`, from the 2026 handbook cover) — candid, unposed, community-focused: volunteer work days and repairs, kids' events, seasonal flyers (fall festival, "Light the Night"), a pianist, board/committee members. A distinctive recurring motif: hand-sewn quilts from the congregation displayed across the stone sanctuary wall — warm, homemade, textile-rich, not corporate. The sanctuary itself is stone-and-wood with a simple wooden cross, not ornate. Keep new photography in this same key: real congregants, natural indoor light, unstaged. Until higher-resolution photography exists, use placeholders.

**Cards.** White surface on the warm page background, 10px radius, 1px `--border-subtle` hairline, `--shadow-sm` (only on hover/interactive cards; static cards can be border-only). No colored left-border accent strip.

## Iconography

No icon set, icon font, or SVG icon library was provided in the brand materials — only the three logo files. Per the "practical, simple" direction, this system uses **Lucide** icons (CDN, MIT-licensed) as a substitution: a stroke-based icon set (1.75px stroke, no fill, 24×24 grid) that reads as plain line-art rather than a decorative icon style — closest match to "no icon system established, pick something restrained." **This is a substitution, not a brand-sourced asset — flagging for the user to confirm or replace.**

- Load via `<script src="https://unpkg.com/lucide@latest"></script>` then `lucide.createIcons()`, or reference individual SVGs from the same CDN package.
- Do not use emoji as icons (see Content fundamentals).
- Unicode glyphs (×, →) are acceptable only for punctuation-like affordances (close, arrow), never as a stand-in for a real icon.
- The only real brand marks are the three logo files in `assets/logos/` — see Brand cards in the Design System tab.

## Ministries & schedule

Real program structure (from the 2026 handbook), for use in the website UI kit and any future scheduling content:

- **Sunday School** 9:30–10:15am — classes for every age, infant through adult (currently one combined adult class), plus a Sunday School Youth class and a Nursery class.
- **Worship Service** 10:30am in the Sanctuary, with parallel Youth Church and Toddler Church.
- **Youth groups**, pre-school through high school; Highway 52 Youth Group meets the 2nd Sunday after church (lunch provided).
- **Women's Bible Study**, Wednesdays 6:45–8:00pm.
- **Small groups** — continuously forming; listed in the weekly bulletin/website or through the Education Ministry chairman.
- **Cancellations** are posted on Channel 13, Facebook, and via One Call Now.

## Leadership (2026)

- **Interim Minister:** Rod Nielsen (stepped in June 2024 after Andrew Ramey, minister for 10 years, was called to full-time Army service at Fort Knox, KY).
- **Elders:** Brian Hoffman (Chairman), Mike Smith (Co-Chairman), Tom Dull, Aaron Lucas, Joe Durham.
- **Deacons:** Alan Martin, Bob Kline, Jon Culbertson, Doug Ladika, Gary Allen, Jim Garland, John Weidman, Kipper Freeman, Larry Metzler.
- **MCC Board:** Chairman Alan Martin, Asst. Chairman Bob Kline, Secretary Jon Culbertson, Asst. Secretary John Weidman, Treasurer Kerry Dull, Asst. Treasurer Alan Martin, Sunday School Secretary Myrtle Cox. Trustees: Jon Culbertson, Gary Allen, Jim Garland.

## Components

Standard primitive set (no source codebase/Figma to enumerate from — see About):

- `components/core/` — Button, IconButton, Card
- `components/forms/` — Input, Select, Checkbox, RadioGroup, Switch
- `components/feedback/` — Badge, Tag, Toast, Tooltip
- `components/navigation/` — Tabs
- `components/overlay/` — Dialog

## Index

- `styles.css` — root stylesheet; `@import`s everything in `tokens/`.
- `tokens/` — `fonts.css` (`@font-face`), `colors.css`, `typography.css`, `spacing.css`, `effects.css` (radii/shadows/motion).
- `assets/logos/` — the three provided logo files. `assets/fonts/` — Calistoga + Nunito binaries + OFL licenses. `assets/photos/` — real reference photo (sanctuary/quilts) cropped from the 2026 handbook.
- `guidelines/` — 15 foundation specimen cards (Colors ×5, Type ×4, Spacing ×2, Brand ×4) shown in the Design System tab.
- `components/core/` — Button, IconButton, Card
- `components/forms/` — Input, Select, Checkbox, RadioGroup, Switch
- `components/feedback/` — Badge, Tag, Toast, Tooltip
- `components/navigation/` — Tabs
- `components/overlay/` — Dialog
- `ui_kits/website/` — click-through church-website recreation (Home, Sermons, Events, Give, Plan your visit, About) using the real schedule/leadership/contact info above.
- `thumbnail.html` — project tile.
- `SKILL.md` — portable Claude-Code-compatible version of this system.

## Fonts — substitution note

No substitution was needed: both **Calistoga** and **Nunito** were supplied directly as font files and are used as-is (see `assets/fonts/`).
