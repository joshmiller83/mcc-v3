# MCC homepage — build report and feedback request

**To:** Claude Design
**From:** the implementation side (Claude Code, in the `mcc-v3` repo)
**Date:** 2026-07-29
**Subject:** `homepage-design.zip` is built. Here's how it landed, what we changed
deliberately, and the eight things we'd like a ruling on before we go further.

---

## 1. TL;DR

The homepage is built and matches the seven-band structure in your handoff. Colour,
type and spacing come from your tokens. Automated audit on the built page:

| Metric | Result |
|---|---|
| Contrast failures | **0** of 96 samples (min ratio 6.97) |
| Heading font (Calistoga) | 89% |
| Body font (Nunito) | 89% |
| Horizontal overflow @ 430/768/940/1440px | **none** |
| Tap targets < 44px | 9 — **all** inside the calendar week grid (see §5.1) |

The four photo slots are wired to your placeholder JPGs as real, editable image
blocks. Everything below is either a deliberate divergence we want you to sign off
on, or a gap we can't close without a decision from the church.

**Screenshots:** `screenshots/` has the built page (desktop, mobile, and logged-in
as an editor) plus a render of your reference for side-by-side.

---

## 2. How this site is actually put together

Worth reading before you judge the divergences — several of them are forced by the
architecture rather than chosen.

### The stack

- **Drupal CMS 11**, hosted on Pantheon. Deploys are `git push` → GitHub Actions →
  Pantheon Integrated Composer. There is no manual deploy step.
- **Base theme: `caresphere_theme`** (contrib). It ships the component library —
  `section`, `section-grid`, `section-intro`, `hero-card`, `card-icon`, `stat-card`,
  `button`, `image`, `blockquote`, `accordion`, and about 20 more.
- **Subtheme: `mcc_theme`** (ours). This is where your design system lives. Your
  `tokens/*.css` are vendored in verbatim at
  `web/themes/custom/mcc_theme/css/tokens/` and are the single source of truth;
  a small mapping layer re-points caresphere's own shadcn-style variables
  (`--background`, `--primary`, `--radius`, …) at your tokens so every base-theme
  component inherits the brand without being forked.

### How a page is composed

Pages are **Canvas** pages (Drupal's new page builder). A page is a *tree* of
components, each with a `uuid`, a `parent_uuid` and a `slot`. An editor drags
components into slots in a visual editor.

The critical structural convention on this site — and the thing your handoff's
"bands" map onto — is:

> **Every band is a `section` component.** The `section` carries the band's
> `section_id` (e.g. `home-hero`), its background, and its vertical padding.
> Everything in that band lives *inside* the section's `content` slot.

Band colours are then applied in `mcc_theme/css/mcc-landing-bands.css`, keyed to
those `section_id`s. That file already served `/get-involved`, `/im-new` and
`/ministries`; the homepage now joins it. **This is why we didn't write a
homepage-specific stylesheet** — the site has one band vocabulary and the homepage
now speaks it.

Why band colours aren't done with the component's own `backgroundcolor` prop: that
prop emits `bg-white` / `bg-black` classes, and because `mcc_theme` remaps
`--background`/`--foreground` onto a light palette, `bg-white` actually resolves to
*near-black* on this site. Repointing those classes is a site-wide job affecting
ten Canvas pages. The `section_id` route is the established workaround.

### What is *not* Canvas

The header, the footer and the newsletter band are **theme-owned** Single Directory
Components (`mcc-header`, `mcc-footer`, `mcc-newsletter-band`), rendered by the page
template and fed from Drupal menus. Editors change them by editing menus, not by
dragging components. This matters for §5.4.

The "This Week at MCC" panel is a **block plugin** over a calendar service, not a
Canvas component and not a view — it renders positioned day columns with derived
multi-day bands and lane packing, which a view cannot produce. It shares its
components with `/calendar` and `/calendar/print`.

### Content vs. code

This is the constraint that shapes our whole delivery: **component trees and media
live in the database, but only code is deployed by git.** So every content change is
written as an idempotent PHP script in `scripts/` that can be re-run on any
environment. The homepage's structure is `scripts/homepage-structure.php`. Your four
placeholder JPGs ship *inside the theme* (`mcc_theme/images/placeholders/`) so they
travel with code, and the script mints the media entities from them on whichever
environment it runs on.

---

## 3. Your priority task — the photo slots — is done, slightly differently

You asked for one reusable image block used four times, with the grey JPGs as
fallbacks. Here's what we did and why it differs.

**We used caresphere's existing `image` component rather than building a new one.**
It already is "the site's image block" — it's what an editor gets under *Base →
Image* in Canvas, it takes a media reference, an aspect ratio and a corner radius,
and it emits a responsive `<picture>` with AVIF derivatives at 15 widths. Building a
parallel block would have given editors two things that look the same.

**The placeholders are real uploaded media, not a CSS fallback.** Each slot has an
actual media entity whose image *is* your grey JPG. This is better than a
"no image selected → show placeholder" fallback for one specific reason: publishing
a real photo is now "replace this image", which an editor already knows how to do.
With a fallback, the slot looks empty in the editor and the volunteer has to guess.

**The alt text is the photo brief.** Rather than describing the grey box, each
placeholder's alt text describes the photo we still need — e.g. *"Placeholder: the
sanctuary — stone wall, wooden cross, congregation quilts on the back wall."* So the
brief is attached to the slot itself and survives this document.

**Two of the four are not the image block:**

| Slot | Implementation | Why |
|---|---|---|
| `stat-photo-1`, `stat-photo-2` | `image` component in the mosaic grid | as specced |
| `cta-photo` | `image` component in a zero-padding full-bleed band | as specced |
| `hero-photo` | the **section's** `background_image` | see below |

The hero photo is the band's background image because `section` already renders a
background layer *plus* an overlay element, and we restyle that overlay into your
115° green scrim. The alternative would have been `hero-card`'s own `media` prop —
but **that prop is inert**: `hero-card.component.yml` declares `media`, and
`hero-card.css` ships `.hero-card__bg`, `.hero-card__image` and `.hero-card__overlay`
rules, but `hero-card.twig` never renders any of them. That's a bug in the base
theme, not in your spec. Worth an upstream report; we routed around it.

---

## 4. Bugs we found and fixed along the way

Listed because several were site-wide and you may see the effects on other pages.

1. **The neutral colour ramp was resolving pink.** `--neutral-100/200/300` were
   `color-mix(in oklch, oatmeal, walnut)`. Measured in Chromium, oklch snapped to
   walnut's hue almost immediately instead of interpolating, so `--neutral-100`
   resolved to `#dbc9c1` — rose, not the warm greige a cream/brown mix should give.
   These feed `--border-subtle/-default/-strong`, so **every border on the site** was
   faintly pink. Switched to `oklab` (which your `--white-warm` token already used
   for exactly this reason); `--neutral-100` now resolves `#d5ccbe`. This is the
   single highest-leverage change in the batch and it is global.

2. **A block of CSS was targeting selectors that never matched.** Rules keyed to
   `div[data-component-id="caresphere_theme:section-intro"]`,
   `…:button`, `…:stat-card` etc. Only `section`, `section-grid` and `hero-card`
   print `{{ attributes }}` in their Twig, and `data-component-id` rides on those
   attributes — so those rules were dead. Among the casualties: the rule meant to
   paint the closing "We'd love to meet you" band green, which is why that band was
   rendering on the page background.

3. **`blockquote { background: #312219 !important }`** — an element selector, not a
   component selector, so *any* blockquote anywhere on the site (a pull quote in a
   bio, a verse in a news story) would have become a full-width dark brown block with
   5.5rem of padding. It existed to style one band on one page. Removed; the mission
   band is now a `section` band like every other band.

4. **The "See all ministries" CTA was `disabled: true`** in stored content, and
   `button.twig` nulls the `href` when disabled — so the section's main call to
   action rendered as an inert `<button disabled>`. It's a link again.

5. **"Plan your visit" pointed at `/i-am-new-here`, which 404s.** The page is
   `/im-new`. This was the homepage's primary conversion CTA.

6. **Buttons were square and outlined in brick red.** caresphere gives both secondary
   variants `border-radius: 0`, and `.button--primary` a `1.5px solid --destructive`
   (brick) border. Now on `--radius-md` with a primary-coloured border, per your
   "10px … cards, buttons" rule.

7. **Green-on-green buttons.** `--color-primary` *is* the green the hero and closing
   bands are painted with, so a primary button on those bands was invisible. On dark
   green bands the filled button is now terracotta — which your hero already did via
   `.hero-card__actions`; we generalised it.

8. **Buttons were 42px tall**, just under your 44px minimum. Fixed globally.

---

## 5. Eight things we'd like you to rule on

### 5.1 Calendar chips are 38px, under your 44px minimum
The nine remaining small tap targets are all event chips inside the "This Week"
grid. They're shared with `/calendar` and `/calendar/print`, and the print sheet
fitting on one Letter page is a hard, tested requirement. Raising chips to 44px makes
the month grid materially taller and risks that test.
**Question:** accept 38px inside dense calendar grids as a documented exception, or
do you want the week panel restyled into a list on the homepage only?

### 5.2 The impact section header is centred, not split
Your reference puts the eyebrow + H2 on the left and the paragraph + "Learn more"
button on the right. We kept it centred, because `section-intro` is a centred
component used identically on the three sibling landing pages, and splitting it here
means either a new component or a page-local override.
**Question:** is centred acceptable, or is the asymmetric header load-bearing?

### 5.3 The events band shows a live week grid, not four event cards
Deliberate and pre-existing: the homepage panel runs through the same calendar
service as `/calendar` so the two can't drift. It also means the band now has two
routes to the calendar — a "See the full calendar ›" link in the panel header (your
design's top-right link) and a "See the full calendar" button below it.
**Question:** keep both, or drop one? We lean keep, but it is visible duplication.

### 5.4 The footer has three link columns, not four, and no oak texture
Your footer is brand chip + Visit / Ministries / Connect / About, on tiled oak at
30%, with the newsletter row inside it. Ours is a logo mark + Visit / Connect /
Contact, on flat walnut, with the newsletter as a separate green band above.
The columns are **menu-driven** — adding "Ministries" and "About" columns means
creating two new menus and deciding what goes in them, which is a church content
decision, not a styling one.
**Question:** we can do the oak texture and merge the newsletter row immediately.
Do you want us to, before the column content is settled? And can you confirm the
intended link list for the two new columns?

### 5.5 The header CTA says "Get Involved", your design says "Plan your visit"
The header is global and was set by the earlier `/im-new` and `/get-involved` work.
Changing it based on one page's mock felt like your call, not ours.
**Question:** change it site-wide, or keep "Get Involved"?

### 5.6 The hero placeholder's own text collides with the hero copy
Visible in `screenshots/drupal-homepage-desktop.png`. The grey JPG's centred caption
sits behind the headline and the "Get involved" ghost button. It resolves the moment
a real photo lands, and the *text contrast* still passes (min 6.97 — the copy is over
your scrim, not over the caption). We did **not** darken the scrim to hide it,
because your spec fixes those gradient stops and a heavier scrim would over-darken a
real photograph.
**Question:** live with it until photography arrives, or would you like a
plainer, caption-free variant of `hero-photo.jpg` for the interim?

### 5.7 The stats are 185+ / 10:30am / 500+, not 185+ / 500+ / 3
The church replaced your "3 — Services & classes every Sunday morning" with
"10:30am — Worship every Sunday morning" in content. It reads fine, but it means the
mosaic has a time where the design had a count, so the three numerals no longer
scan as a set.
**Question:** any objection, or should we push back on the content side?

### 5.8 The mosaic's history paragraph is now a card
Your spec has it as a plain grid cell. Sitting between three bordered stat cards it
read as text that had fallen out of the grid, so we gave it the same
`--surface-card` + border treatment. Easy to revert.

---

## 6. What we need from the church (not from you)

- **Real photography** for all four slots. Direction from your brand system —
  real congregants, natural indoor light, unstaged, no stock — is recorded in each
  placeholder's alt text.
- **A higher-resolution oak texture**, if §5.4 goes ahead. The one in the bundle is
  flagged low-res in your own asset table.
- **Footer column content** for Ministries and About (§5.4).

---

## 7. Files in this bundle

```
README.md                                  this document
screenshots/
  drupal-homepage-desktop.png              the built page, 1440px
  drupal-homepage-mobile.png               the built page, 430px
  drupal-homepage-logged-in.png            as an editor sees it (admin sidebar)
  design-reference-desktop.png             your MCC Homepage.dc.html, rendered
data/
  audit.json                               contrast / type / tap-target / line-length
  component-map.json                       the Canvas tree: every component,
                                           its uuid, parent, slot and inputs
  rendered-homepage.html                   full HTML source with Twig debug comments
  *.jpg                                    the four placeholders, as shipped
```

`component-map.json` is the useful one if you want to reason about what an editor
can actually change: every entry is a real component with real, editable inputs.

---

## 8. Where the code lives

| Change | File |
|---|---|
| Design tokens (yours, vendored) | `web/themes/custom/mcc_theme/css/tokens/*.css` |
| Band colours, hero scrim, mosaic | `web/themes/custom/mcc_theme/css/mcc-landing-bands.css` |
| Base-theme mapping + component fixes | `web/themes/custom/mcc_theme/css/global-overrides.css` |
| Homepage structure + placeholder media | `scripts/homepage-structure.php` |
| Placeholder JPGs | `web/themes/custom/mcc_theme/images/placeholders/` |
| Screenshot + audit tool | `scripts/im-new-review.mjs` |
