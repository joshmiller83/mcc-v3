# Handoff: MCC Homepage

## Overview

The homepage for Mechanicsburg Christian Church (Kirklin, IN — est. 1840, "We Love People!").
Single scrolling page, seven bands:

1. Sticky header (logo, 4 nav links, "Plan your visit" button)
2. Hero — full-bleed photo + green gradient scrim, headline, two CTAs
3. "Deep roots" impact section — stat/photo mosaic (or a plain 3-stat row)
4. "Ways we serve together" — 3 icon pillars on the card surface
5. "Upcoming at MCC" — 4 date-badge event cards (or a compact list)
6. Mission-statement band (terracotta) + green closing CTA band
7. Full-bleed closing photo, then wood-texture footer (newsletter, 5 columns, legal row)

## About the design files

The files in this bundle are **design references created in HTML** — a prototype showing intended
look and behavior, **not production code to copy**. Your job is to **recreate this design in the
target codebase using its established patterns** (Drupal theme + blocks, React, whatever is in
place). If no environment exists yet, pick the most appropriate one and implement there.

Open `MCC Homepage.dc.html` directly in a browser to see the design. `support.js`, `image-slot.js`
and `_ds/` are the prototype's runtime and design-system bundle — reference them for exact values,
don't ship them.

## Fidelity

**High fidelity.** Colors, type, spacing, and copy are final. Recreate pixel-for-pixel using the
codebase's own component library where equivalents exist (buttons, inputs, cards).

---

## ⚠ Priority task: photo placeholders → a real image block

The design has **four photo slots**. In the prototype they are `<image-slot>` custom elements — a
drag-and-drop dev affordance that must **not** ship. Replace each one with a **single reusable
image block** in the site's page-builder/canvas block system, used four times with different
configuration.

**What the block needs:**

| Requirement | Detail |
|---|---|
| Fields | image (media reference), alt text, focal point / object-position, aspect-ratio or fill mode, optional overlay (none / green gradient scrim) |
| Fill modes | `fill` (absolutely positioned, `object-fit:cover`, fills its parent — hero and closing band) and `fixed-ratio` (square-ish tile that stretches to grid-cell height, `min-height:220px` — impact mosaic) |
| Fallback | when no image is selected, render the shipped grey placeholder JPG — same markup, same box, no layout shift, no empty space |
| Alt text | required for real images; for the fallback use the placeholder's own description |
| Loading | hero eager + `fetchpriority=high`; the other three lazy |

**The fallback JPGs ship in `placeholders/`.** Each is a flat grey field (`#d6d3cc`), faint diagonal
hatch, a thin frame, and centered text naming the photo that belongs there, its crop, and its
minimum size. They are deliberately plain and legible at thumbnail size so a church volunteer
editing the page understands what to upload without reading documentation. Wire them as the block's
default image (or a per-instance default) — one file per slot:

| Slot id | Placeholder file | Photo we need | Box in the design |
|---|---|---|---|
| `hero-photo` | `placeholders/hero-photo.jpg` (2000×1240) | Congregation or sanctuary, wide. Subject must sit **right of center** — the green scrim covers the left ~45%. | Fill, `position:absolute; inset:0`, inside a `min-height:620px` section |
| `stat-photo-1` | `placeholders/stat-photo-1.jpg` (900×900) | The sanctuary — stone wall, wooden cross, congregation quilts on the back wall | Grid cell, `width:100%; height:100%; min-height:220px`, `border-radius:10px` |
| `stat-photo-2` | `placeholders/stat-photo-2.jpg` (900×900) | Sunday worship in progress; candid, natural indoor light, unposed | Same as above |
| `cta-photo` | `placeholders/cta-photo.jpg` (2400×840) | The congregation together — group shot or fellowship moment. No text overlays it. | Fill, inside a `width:100%; height:420px` wrapper directly below the green CTA band |

Photography direction (from the brand system): real congregants, natural indoor light, unstaged, no
stock. If higher-res church photography isn't available yet, the greys are safe to launch with — the
page reads correctly with all four placeholders in place.

---

## Design tokens

All values come from `_ds/.../tokens/*.css`. Base brand colors are exact hex; the scales are derived
with `color-mix(in oklch, …)` off those bases — keep that derivation rather than hardcoding steps,
or resolve them once and paste the computed values if the codebase can't do `color-mix`.

**Color bases**

| Token | Value |
|---|---|
| `--green-700` (primary) | `#2f4833` Forest Green |
| `--terracotta-500` | `#ae5b33` Warm Terracotta |
| `--walnut-700` | `#4e3426` Deep Walnut |
| `--oatmeal` | `#e9e3d5` page background |

**Semantic aliases used on this page**

`--surface-page: --oatmeal` · `--surface-card: --white-warm` (oatmeal 35% / white 65%) ·
`--neutral-50: --white-warm` · `--color-primary: --green-700` · `--color-primary-subtle: --green-50`
· `--color-secondary: --terracotta-700` · `--text-body: --neutral-900` · `--text-muted:
--neutral-600` · `--text-on-inverse: --oatmeal` · `--text-link: --terracotta-700` ·
`--text-link-hover: --terracotta-800` · `--border-subtle: --neutral-100` · `--border-default:
--neutral-200`.

Band backgrounds: hero scrim `linear-gradient(115deg, green-950@92%, green-900@60% 45%,
green-900@30% 100%)`; ministries band `--surface-card`; events band `--neutral-50`; mission band
`--terracotta-900`; closing CTA `--green-900`; footer `--walnut-900` + oak texture.

**Spacing** — 4px scale in rem: `--space-1` .25 · `-2` .5 · `-3` .75 · `-4` 1 · `-5` 1.25 · `-6` 1.5
· `-8` 2 · `-10` 2.5 · `-12` 3 · `-16` 4 · `-20` 5 · `-24` 6 · `-32` 8rem. `--container-max: 1200px`.

**Type** — two families, strict roles.
`--font-display` = **Calistoga** 400 only: h1 56/1.08, section h2 34, card titles 19–21, stat
numerals 40–44, footer h3 24. Never body, never UI labels.
`--font-body` = **Nunito** (variable 200–1000, has italic): body 15–19/1.6, nav 15 bold, eyebrows 13
bold uppercase with `--tracking-eyebrow`, legal 13, buttons 18 bold (lg) / 15 (sm). Italic Nunito
only for the tagline and the mission quote.

**Radii** 6px small controls · 10px (`--radius-md`) cards, buttons, dialogs, photo tiles · 999px
tags only. **Shadows** restrained green-tinted sm/md/lg, cards on this page are border-only.
**Motion** 120–180ms `cubic-bezier(.4,0,.2,1)` on color/opacity only — no transforms, no scroll
animation.

---

## Screens & components

### Header
Sticky, `top:0`, `z-index:50`, `--surface-page` background, 1px `--border-default` bottom.
Inner row: `max-width:1200px`, `padding:14px var(--space-6)`, flex, space-between, `gap:24px`.
Logo `MCC-logo-horizontal.svg` at `height:42px`. Nav: flex, `gap:32px`, links Nunito 15 bold
`--text-body`, hover `--color-primary` no underline. Right: primary Button, size sm, "Plan your visit".
**Nav and button labels must not wrap** — `white-space:nowrap; flex:none`. Below ~940px, collapse
nav to a menu button rather than letting the row overflow (this bit the previous page handoff).

### Hero
`min-height:620px`, flex centered, `overflow:hidden`. Photo fills; gradient scrim above it with
`pointer-events:none`; content `z-index:1`, `max-width:620px` inside the 1200px container.
Eyebrow 13 bold uppercase, `--text-on-inverse` at .8 opacity: "Est. 1840 · Kirklin, Indiana".
H1 Calistoga 56/1.08: "You're welcome here." Body 19/1.6, `max-width:480px`, opacity .92.
CTAs: `display:flex; gap:16px; flex-wrap:wrap` — secondary Button lg "Watch a sermon", plus a ghost
button (transparent, `1px solid rgba(255,255,255,.7)`, radius 10, `14px 28px`, 18px bold, hover
`background:rgba(255,255,255,.15)`) "Get involved".
Contrast note: white text sits over the scrim, not over raw photo — keep the scrim if you swap the image.

### Impact section ("Deep roots. A growing community.")
`max-width:1200px`, `padding:var(--space-24) var(--space-6)`.
Header row: flex, space-between, `align-items:flex-end`, wraps, `margin-bottom:var(--space-10)`.
Left: terracotta eyebrow "Since 1840" + h2 34. Right (`max-width:400px`): 16/1.6 muted paragraph +
outline Button md "Learn more".
**Mosaic variant (default):** `grid-template-columns:repeat(3,1fr); gap:var(--space-6)`, six cells in
order — stat 185+ / photo / stat 500+ / history paragraph / stat 3 / photo. Stat cards:
`--surface-card`, 1px `--border-default`, radius 10, `padding:var(--space-8)`, flex column centered;
numeral Calistoga 44 `--color-secondary`, label Nunito 15 muted.
**Row variant:** three centered stat cards, numerals 40, no photos.
Copy — 185+ "Years serving Kirklin" · 500+ "Meals served at Shalom House each year" · 3 "Services &
classes every Sunday morning" · history paragraph as in the HTML.

### Ministries band
`--surface-card` background, `padding:var(--space-24) var(--space-6)`. Centered intro,
`max-width:640px`, `margin-bottom:var(--space-16)`: eyebrow "How we serve", h2 34 "Ways we serve
together", 16/1.6 muted lede. Then `repeat(3,1fr)` grid, `gap:var(--space-10)`, each pillar centered
with a 64px circle `--color-primary-subtle` holding a 28px Lucide icon in `--color-primary`
(`utensils`, `book-open`, `globe`), h3 Calistoga 21, 15/1.6 muted body. Footer: outline Button md
"See all ministries", `margin-top:var(--space-16)`.
Icons are **Lucide** (MIT) — a documented substitution; swap for the codebase's icon set if it has one.

### Events band
`--neutral-50`, `padding:var(--space-24) var(--space-6)`. Header row flex space-between
`align-items:baseline`, wrapping: eyebrow "What's next" + h2 "Upcoming at MCC"; right a 15 bold link
"See the full calendar →".
**Cards variant (default):** `repeat(4,1fr)`, `gap:var(--space-6)`. Card = `--surface-card`, 1px
`--border-default`, radius 10, `overflow:hidden`; top strip `--color-primary` with 12px uppercase
month and Calistoga 32 day; body `padding:var(--space-5)` with Calistoga 19 title and 14 muted
"Weekday · time".
**List variant:** one card `max-width:560px`, `padding:var(--space-8)`, grouped by date; each row
flex `gap:16px`, 76px fixed time column, title as a link, 1px `--border-subtle` top rule.
Events are live data — the four shown are sample content from the church calendar.

### Mission band (toggleable)
`--terracotta-900`, `padding:var(--space-20) var(--space-6)`, centered. Eyebrow "Our mission" at .75
opacity, then the mission statement verbatim in **italic Nunito 24/1.55**, `max-width:820px`:
"We walk by faith, embracing all that God desires, reaching the world, through Jesus Christ!"

### Closing CTA + photo
`--green-900`, `padding:var(--space-24) var(--space-6)`, centered: h2 Calistoga 36 "We'd love to meet
you.", 17 body at .9 opacity `max-width:520px`, then flex `gap:16px` centered — secondary Button lg
"Plan your visit" and the same ghost button "Give".
Directly below: `width:100%; height:420px` wrapper holding the `cta-photo` slot, no padding, full bleed.

### Footer
`--walnut-900`, `overflow:hidden`, two stacked absolute layers: `assets/oak-wood.jpg` tiled at
`background-size:340px`, `opacity:.3`, then a `--walnut-900` layer at `opacity:.78`. Content
`z-index:1`, 1200px, `padding:var(--space-16) var(--space-6) var(--space-8)`.
Newsletter row: flex space-between, wraps, `padding-bottom:var(--space-12)`, 1px
`rgba(255,255,255,.15)` bottom rule — Calistoga 24 "Stay connected" + 15 body at .85; right, Input
(placeholder "Your email address", ~260px) + secondary Button md "Subscribe".
Link grid: `grid-template-columns:1.4fr repeat(4,1fr)`, `gap:var(--space-8)`, `padding:var(--space-12) 0`.
First cell: oatmeal chip (radius 10, `10px 14px`) with `MCC-logo-icon.svg` at 32px and the two-line
wordmark in Calistoga 15 `--walnut-900`, then italic "We Love People!" at .85.
Four link columns — Visit / Ministries / Connect / About; headings 14 bold uppercase at .7 opacity,
`margin-bottom:16px`; items in a flex column, `gap:10px`, 14px at .85 opacity.
**Only real links are anchors.** The street address and phone are text with a `tel:` anchor on the
number only; don't wrap non-navigating strings in `<a>`.
Legal row: flex space-between, wraps, `padding-top:var(--space-8)`, 1px top rule, two 13px spans at
.65 opacity — "© 2026 Mechanicsburg Christian Church · Est. 1840 · We Love People!" and "650 W.
Horton Road, Kirklin, IN 46050 · (765) 325-2772".

---

## Interactions & behavior

- Header is sticky; nothing else is scroll-driven. No parallax, no reveal animations.
- Hover: nav → primary green; links → `--text-link-hover` + underline; filled buttons lighten one
  step; ghost buttons gain `rgba(255,255,255,.15)`; outline buttons gain a subtle tint. All
  120–180ms on color only.
- Active/press: one step further, drop any shadow. Focus: solid brand-color outline ring, never a glow.
- Newsletter form: email required + format check, inline error under the field using `--color-error`,
  success replaces the row with a short confirmation. Not wired in the prototype.
- Tap targets ≥44px everywhere, including footer links and nav on mobile.

### Responsive

Not built in the prototype — implement these:
- ≥1200px as shown. 1024–1199px: same structure, container padding only.
- ~940px: nav → menu button; impact mosaic → 2 columns; ministries → 2 columns; events → 2 columns.
- ≤680px: everything single column; hero `min-height` ~520px and h1 ~40px; h2 ~28px; closing photo
  height ~260px; footer grid stacks with the brand cell first; both header/footer rows wrap.
- Photo blocks keep `object-fit:cover` at every breakpoint; hero keeps subject right-of-center at
  desktop but should recenter (or use the block's focal point) below 680px.

## State

Presentational page. Only state needed:
- `statsLayout`: `'mosaic' | 'row'` (default mosaic) — impact section variant
- `eventsLayout`: `'cards' | 'list'` (default cards) — events section variant
- `showMissionBand`: boolean (default true)
- newsletter form: `email`, `status: idle | submitting | success | error`

If the CMS owns the page, expose those three layout choices as block settings, not code branches.
Events and ministries should read from real content; stats and copy are editable text.

## Assets

| File | Origin | Notes |
|---|---|---|
| `assets/MCC-logo-horizontal.svg` | church-supplied | header, 42px tall |
| `assets/MCC-logo-icon.svg` | church-supplied | footer chip, 32px |
| `assets/oak-wood.jpg` | crop of a church reference photo | footer texture only, tiled 340px at .3 opacity — low-res, request higher-res oak before using it larger |
| `assets/sanctuary-quilts.jpg` | 2026 handbook cover crop | real photo, low-res; a candidate for `stat-photo-1` once a better scan exists |
| `placeholders/*.jpg` | generated for this handoff | grey fallbacks for the four photo slots |
| Lucide icons | unpkg CDN, MIT | substitution — no brand icon set exists |
| Calistoga, Nunito | in `_ds/.../assets/fonts/` (OFL) | self-host, don't CDN |

## Files

- `MCC Homepage.dc.html` — the design (open in a browser)
- `placeholders/` — the four grey photo placeholders
- `assets/` — logos and textures used by the page
- `_ds/mechanicsburg-.../` — design-system tokens (`tokens/*.css`), `styles.css`, component bundle,
  fonts. Read tokens here for any value not listed above.
- `support.js`, `image-slot.js` — prototype runtime only, do not ship
