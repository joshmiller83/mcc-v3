# Handoff: MCC Church Calendar — screen + print

## Overview

Two views of one dataset for Mechanicsburg Christian Church (Kirklin, IN):

1. **Screen calendar** — a month grid on the church website. Shows *every* event (no "+3 more" truncation), colour- and shape-coded by ministry type, with multi-day events drawn as continuous bands across the week. Has a **Print this month** button.
2. **Print sheet** — the same month, laid out to fill one US-Letter **portrait** sheet exactly, for the monthly paper calendar the office prints and hands out. No manual pixel-fiddling: week rows are `1fr`, so 5-week and 6-week months both stretch to fill the page.

The office prints one sheet per month, so the print view is a first-class deliverable, not an afterthought.

## About the design files

The files in `designs/` are **design references written in HTML** — prototypes that demonstrate the intended look, layout maths, and behaviour. They are **not production code to copy**. The task is to **recreate these designs in the target codebase's own environment** (React, Vue, Rails views, Astro, whatever the church site uses) using its established patterns, routing, and data layer. If no environment exists yet, pick the most appropriate framework for a small church site and implement there.

The prototypes are authored as "Design Components" (`.dc.html` + `support.js` runtime). Read them for structure, values, and algorithms; do not port `support.js`, `sc-for`, `sc-if`, or `{{ }}` templating into the real app — those are prototype-only constructs. Their direct equivalents:

| Prototype construct | Real-code equivalent |
| --- | --- |
| `<sc-for list="{{ items }}" as="item">` | `items.map(...)` / `v-for` / each loop |
| `<sc-if value="{{ flag }}">` | conditional render |
| `renderVals()` returning values | component state + derived values |
| `data-props` JSON on the script tag | component props / feature flags |
| `<doc-page>` custom element | your own print-CSS wrapper (see **Print geometry**) |

## Fidelity

**High-fidelity.** Colours, type sizes, spacing, borders, and the print page maths are final and should be reproduced exactly. All values below are literal. The only intentionally-open items are listed under **Open questions**.

## Data model

Everything is derived from four constants (see either design file, top of the `<script>`).

### Event type (drives colour + shape marker)

Five types. Each type = one colour + one geometric marker. Markers are drawn in CSS (no icon font, no SVG), all optically bullet-sized, so they stay crisp in print.

| Type key | Label | Colour token | Marker | Marker CSS |
| --- | --- | --- | --- | --- |
| `worship` | Worship | `--green-800` | filled circle | `5×5px; border-radius:50%` |
| `serve` | Serve | `--terracotta-600` | triangle | `6×5px; clip-path:polygon(50% 0%,100% 100%,0% 100%)` |
| `fellowship` | Fellowship | `--walnut-600` | square | `5×5px; border-radius:1px` |
| `youth` | Youth | `--brick-600` | open ring | `5×5px; border-radius:50%; background:transparent; border:1.3px solid <colour>` |
| `lead` | Leadership | `color-mix(in oklch, var(--green-700) 45%, var(--terracotta-500) 55%)` | diamond | `4.5×4.5px; border-radius:0.5px; transform:rotate(45deg)` |

Chip/band tints (screen view only):

- worship `var(--green-50)`
- serve `color-mix(in oklch, var(--terracotta-500) 12%, var(--white) 88%)`
- fellowship `color-mix(in oklch, var(--walnut-700) 10%, var(--white) 90%)`
- youth `oklch(96% 0.02 28)`
- lead `color-mix(in oklch, var(--terracotta-500) 7%, var(--oatmeal) 93%)`

An earlier iteration used Lucide icons (church / hand-heart / users / backpack / clipboard-list) and a three-dot Youth marker. Both were rejected: icons are illegible at 7pt in print, and three dots don't survive bullet scale. **Use the geometric set above.**

### 1. Recurring events (`RECURRING`)

`{ dow, nth, h, m, title, s, type }`

- `dow` 0=Sunday … 6=Saturday.
- `nth` = 1-based week-of-month, or `0` for **every** week. (`nth` is computed as `Math.floor((dayOfMonth - 1) / 7) + 1` — i.e. days 1–7 are "1st", 8–14 "2nd". This matches how the church says "second Sunday".)
- `s` = short label used on the print sheet only (`Sunday school` vs `Sunday school, all ages`).

Real MCC schedule currently encoded:

| When | Time | Event | Type |
| --- | --- | --- | --- |
| Every Sun | 8:30a | Worship team rehearsal (`rehearsal`) | worship |
| Every Sun | 9:30a | Sunday school, all ages (`Sunday school`) | worship |
| Every Sun | 9:30a | Youth Sunday school | youth |
| Every Sun | 9:30a | Nursery class (`nursery`) | youth |
| Every Sun | 10:30a | Worship service | worship |
| Every Sun | 10:30a | Youth church | youth |
| Every Sun | 10:30a | Toddler church | youth |
| 2nd Sun | 11:45a | Highway 52 youth group | youth |
| 1st Mon | 6:30p | Finance ministry meeting | lead |
| 1st Mon | 7p | Ministry heads meeting | lead |
| 3rd Mon | 6p | Communications committee | lead |
| 3rd Mon | 7p | Elders meeting | lead |
| Every Tue | 3:30p | Shalom House meal | serve |
| Every Wed | 6:45p | Women's Bible study | fellowship |
| Every Wed | 7p | Young adults Bible study | fellowship |
| 2nd Wed | 6p | Buildings & grounds committee | lead |
| 3rd Wed | 7:30p | Deacons meeting | lead |

### 2. Single-day dated events (`ONE_OFFS`)

Keyed `"YYYY-M-D"` with a **0-based month** (`'2026-7-8'` = 8 Aug 2026). Sample content: Battle of the Bands fundraiser, church work day, fall kickoff carry-in dinner, fall festival, Light the Night.

### 3. Multi-day events (`MULTI_DAY`)

`{ start: [y, m0, d], days, title, type, h?, m?, daily? }` — `days` is total length inclusive. `h`/`m` optional; `daily: true` renders the time as "6p daily". Samples: Boone County 4-H Fair (8 days), Vacation Bible School (5), Appalachia mission trip (7), quilt display (4), elders retreat (3).

### 4. Time formatting

Times are always maximally short: **`7p`, `6:45p`, `8:30a`, `9a`** — never `7:00 PM`. Minutes are omitted when zero.

```js
function fmtTime(h, m) {
  const hr = h % 12 === 0 ? 12 : h % 12;
  return hr + (m ? ':' + String(m).padStart(2, '0') : '') + (h < 12 ? 'a' : 'p');
}
```

## Month grid algorithm (shared by both views)

```
first     = new Date(y, mo, 1).getDay()           // leading blanks
daysIn    = new Date(y, mo + 1, 0).getDate()
weekCount = Math.ceil((first + daysIn) / 7)       // 4, 5 or 6
```

Each week is rendered as its **own** 7-column grid so multi-day bands can span columns:

- **Row 1** — day numbers.
- **Rows 2 … (2 + laneCount - 1)** — one row per multi-day *lane*.
- **Last row** — the per-day single-event list (one grid cell per weekday).
- A full-height background cell per column (`grid-row: 1 / -1`) paints the day tint and the hairline borders beneath everything.

`grid-template-rows` is generated per week: screen `('auto ' × (laneCount + 2))`; print `('auto ' × (laneCount + 1)) + ' 1fr'` so the event list absorbs leftover height.

### Multi-day band segmentation + lane packing

For each week `[weekStart … weekStart+6]`, intersect every multi-day event with the week (all comparisons on integer day indices, `Math.round(date.getTime() / 86400000)`):

```
from = max(eventStart, weekStart); to = min(eventEnd, weekEnd)
if (from > to) skip
colStart = from - weekStart + 1;  span = to - from + 1
isStart  = from === eventStart;   continues = to < eventEnd
```

Then greedy lane packing: sort by `colStart` asc, `span` desc; place each segment in the first lane with no column overlap; `gridRow = lane + 2`.

Segment edge treatment:

- `isStart` → 3px (screen) / 2pt (print) coloured left border, left corners rounded, 5px/3px left margin, time shown once.
- `!isStart` → no left border, square left corners, zero left margin (so the band reads continuous across the week boundary).
- `continues` → square right corners, zero right margin, and a `››` marker at the right edge.

## Screen view — `designs/MCC Calendar.dc.html`

Route: church-site page under Events. Reuses the site header (sticky, logo left, About / Ministries / Events / Give, "Plan your visit" button) and the walnut wood-texture footer.

- Container `max-width:1400px; padding:0 1.5rem`.
- Eyebrow "CHURCH CALENDAR" — 13px, 700, `letter-spacing:.08em`, uppercase, `--color-secondary`.
- Month title — Calistoga 44px/1, `--color-primary`.
- Controls, right-aligned: circular `‹` / `›` buttons (44×44, `border-radius:999px`, 1px `--border-strong`, hover `--color-primary-subtle` bg + `--color-primary` border), pill "Today" (44px tall, 22px side padding), then the primary **Print this month** link-button (44px tall, 20px padding, `--radius-md`, `--color-primary` fill, `--text-on-primary`, printer icon 16px). It navigates to the print route carrying the viewed month: `MCC%20Calendar%20Print.dc.html#<year>-<month0>`.
- Legend row — one pill per type: marker + 13px/700 label in the type colour, tinted background, 1px `--border-subtle`, `border-radius:999px`, `padding:5px 14px 5px 10px`.
- Grid card — 1px `--border-default`, `--radius-md`, `overflow:hidden`, `--surface-card` bg. Weekday header band `--green-900`, 12px/700 uppercase white, `letter-spacing:.08em`.
- The grid sits in an `overflow-x:auto` wrapper with `min-width:1180px`, so narrow windows scroll rather than squeezing cells (this is what stops mid-word title breaks).
- Day cells: `min-height` 148px comfortable / 118px compact; `--white` normal, `color-mix(in oklch, var(--oatmeal) 55%, var(--white) 45%)` for adjacent-month days, `color-mix(in oklch, var(--terracotta-500) 8%, var(--white) 92%)` for today; 1px `--border-subtle` right/bottom hairlines; day number 15px/700 (`--text-faint` when out of month); today also gets a terracotta "TODAY" pill (10px/700 uppercase, white on `--color-secondary`, `border-radius:999px`, `padding:2px 7px`).
- Single-day chip: `display:flex; flex-wrap:wrap; gap:2px 5px`, tinted bg, 3px left border in the type colour, `border-radius:0 5px 5px 0`, `padding:4px 6px 4px 5px`. Contents: 12px marker box, title (12px/1.25, 700, `overflow-wrap:normal; word-break:keep-all` so words never split), time (11px/700 in the type colour, `opacity:.85`). Hover `filter:brightness(.97)`.
- Multi-day band: tinted bg, 1px full border in the type colour, 12px marker, 12px/700 title, 11px time, `››` when continuing.

Feature flags (prototype `data-props`, ship as props or config): `density: 'comfortable' | 'compact'`, `showLegend: boolean`.

## Print view — `designs/MCC Calendar Print.dc.html`

Single US-Letter **portrait** sheet per month. Everything is sized in **pt** (not px) and nothing uses viewport units.

### Print geometry

The prototype uses a `<doc-page size="letter">` wrapper with one `<section class="page">` child. In production, reproduce its behaviour:

- Page box exactly `8.5in × 11in`, `overflow:hidden`, content designed to fill it.
- `@page { margin: 0 }` so the browser draws no date/URL/page-number chrome; the visual margin lives in the sheet's own padding (`0.28in 0.28in 0.24in`).
- Screen toolbar (back link, month arrows, Print button) is `display:none` in `@media print`.
- The sheet is a flex column: header → weekday band → grid (`flex:1; min-height:0`) → footer. The grid's `grid-template-rows` is `1fr` repeated `weekCount` times — **this is the "stretch to fit" mechanism**; do not hard-code row heights.

### Sheet contents

- Header: Calistoga 17pt month title in `--green-800`, italic 8pt "Mechanicsburg Christian Church · We Love People!", legend right-aligned (10px marker box + 7.5pt/700 label). 2px `--green-800` rule beneath, `padding-bottom:5px`.
- Weekday band: `--green-800`, 7pt/700 uppercase white, `letter-spacing:.06em`, `padding:2px`, abbreviated (Sun … Sat).
- Grid hairlines: `0.6pt solid var(--neutral-300)`. Adjacent-month days `color-mix(in oklch, var(--oatmeal) 45%, var(--white) 55%)`. Day numbers 8pt/700/1.1, `padding:1px 4px 0`.
- Event line (normal days): one line per event, hanging indent — `padding-left:10px; text-indent:-10px`, 7pt/1.25. Order within the line: 7px marker box (`margin-right:3px`) → **outlined** time chip → title (700, type colour). Wrapped lines therefore align to the text, not under the marker.
- Time chip: `display:inline-block; border:0.6pt solid var(--walnut-400); border-radius:3px; padding:0 2.5px; margin-right:3px; font-size:5.5pt; line-height:1.25; color:var(--walnut-600); background:transparent; white-space:nowrap; vertical-align:1px`. **Outlined, never reversed/filled.**
- Multi-day band: tinted bg, `0.6pt` border in the type colour, `line-height:1.35` (needed — at `line-height:1` Nunito's descenders were clipped), 6.8pt/700 title, 6.5pt meta, `››` continuation marker.
- Footer: 7pt `--walnut-600` — address/phone/site left, closings note right.

### Busy-day layouts (the Sunday problem)

A Sunday carries 7 standing events; at ~1.05in column width, one-line-per-event does not fit. Days with **≥ 4 events** switch to a busy-day layout, selected by the `busyDayStyle` flag:

1. **`grouped`** (default, recommended) — the outlined time chip prints **once per time slot**, on that slot's first event; the rest of the slot's events follow as marker-led lines with the same hanging indent. Sunday becomes 7 lines + 3 chips.
2. **`runs`** — each time slot collapses to one flowing line: chip, then markers + short titles joined by ` · `, hanging indent from the chip. Most compact.
3. **`digest`** — standing weekly items are lifted out of the grid into an "Every week" band under the header (`--green-50` bg, `0.6pt --green-200` border, 6.5pt uppercase "EVERY WEEK" label, 7pt body, clauses per weekday joined by `  |  `); day cells then show only that day's specials, and any day that also had standing items shows an italic 6.2pt `--green-700` note "Standing schedule above". Emptiest, most legible grid.

Flags: `busyDayStyle: 'grouped' | 'runs' | 'digest'` (default `grouped`), `showAdjacentDays: boolean` (default `true`).

### Fit invariant — please keep this test

The sheet must never clip text. The prototype was validated by asserting that **no descendant of `.page` has `scrollHeight > clientHeight + 1`** (excluding elements with `overflow:visible`), across a 6-week month (August 2026, whose worst Sunday sits under two multi-day lanes) and 5-week months. Port this as a visual-regression or DOM assertion; it catches every regression we hit while tuning (chips without `flex:none`, line-heights too tight, bands clipping descenders).

## Interactions & behaviour

- Month arrows shift by one month; recurring rules regenerate, so any month in any year populates. "Today" returns to the current month (hard-coded to July 2026 in the prototype — wire to the real clock).
- Screen "Print this month" → print route with `#<year>-<month0>`; the print view reads the hash on mount and defaults to that month. Its own "Print this month" button calls `window.print()`.
- Event chips are `<a href="#">` placeholders — wire to an event-detail route or modal.
- Hover: chips/bands `filter:brightness(.97)`; nav buttons take a `--color-primary-subtle` background and `--color-primary` border.
- Transitions: 120–180ms `cubic-bezier(.4,0,.2,1)` on colour only. No motion beyond that (brand rule).
- Screen view is not yet responsive below ~1180px; it scrolls horizontally. A real mobile treatment (agenda list) is an open question.

## State

| State | Where | Notes |
| --- | --- | --- |
| `{ y, mo }` viewed month | both views | print view seeds from `location.hash` |
| `density`, `showLegend` | screen | flags |
| `busyDayStyle`, `showAdjacentDays` | print | flags |

No data fetching in the prototype — events are module constants. In production these become the church's calendar source (a CMS collection, Google Calendar feed, or a small admin table). Keep the three shapes (recurring rule / dated one-off / multi-day span); the recurring-rule form is what makes the sheet fill correctly without hand-entry each month.

## Design tokens

Copied verbatim in `tokens/` (`fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `effects.css`) plus `styles.css` which imports them. Use these rather than re-deriving values.

Four reference colours; every other step is a `color-mix(in oklch, …)` off them:

- Forest Green `#2f4833` (`--green-700`, primary)
- Warm Terracotta `#ae5b33` (`--terracotta-500`, secondary)
- Deep Walnut `#4e3426` (`--walnut-700`, ink/neutral anchor + wood texture)
- Oatmeal `#e9e3d5` (`--oatmeal`, page background)

Plus `--brick-500/600/700` (`oklch(52% 0.15 28)` and darker) used only for the Youth type.

Semantic aliases used here: `--color-primary`, `--color-secondary`, `--surface-page`, `--surface-card`, `--text-body`, `--text-muted`, `--text-faint`, `--text-on-inverse`, `--border-subtle`, `--border-default`, `--border-strong`.

Type: **Calistoga** 400 (display only — month title), **Nunito** variable (everything else). Weights available: `--fw-regular:400`, `--fw-medium:600`, `--fw-bold:700`, `--fw-heavy:800`. Note there is **no** `--fw-semibold` — a declaration using it silently drops to 400.

Radii `6 / 10 / 16 / 999px`; spacing `--space-1 … --space-32` on a 4px base; shadows `--shadow-sm/md/lg` (green-tinted, very restrained).

## Assets

- `assets/MCC-logo-horizontal.svg`, `assets/MCC-logo-icon.svg` — the only ground-truth brand marks.
- `assets/oak-wood.jpg` — small oak crop, tiled at 340px with a `--walnut-900` overlay at `.78` for the footer only. Low-res: ask the church for higher-resolution oak photography before using it larger.
- No icon font or SVG icon set is needed for the calendar — all markers are CSS shapes.
- `designs/MCC Homepage.dc.html` is included for context (header/footer/nav vocabulary the calendar inherits). It references `image-slot.js` photo placeholders that are not part of this handoff.

## Open questions

1. **Real event data source** — what feeds the calendar (CMS, Google Calendar, hand-entered)? The recurring-rule model above assumes rules, not 52 copies of each weekly event.
2. **Mobile screen layout** — horizontal scroll is a stopgap; an agenda/list view for phones is unspecified.
3. **Busy-day layout choice** — `grouped` ships as default; the office may prefer `digest` once they see both on paper.
4. **A4** — everything is Letter; if any printing happens on A4 the page box and the fit test need a second pass.
5. **Event detail** — chips link nowhere yet.

## Files

```
design_handoff_church_calendar/
├── README.md                       ← this document
├── designs/
│   ├── MCC Calendar.dc.html        ← screen month view (open directly in a browser)
│   ├── MCC Calendar Print.dc.html  ← Letter portrait print sheet
│   ├── MCC Homepage.dc.html        ← context: site header/footer vocabulary
│   ├── doc-page.js                 ← print-page wrapper used by the print sheet
│   └── support.js                  ← prototype runtime (do NOT port)
├── tokens/                         ← design tokens (colors, type, spacing, effects, fonts)
├── styles.css                      ← imports tokens/
└── assets/                         ← logos + wood texture
```

To view a prototype: open `designs/MCC Calendar.dc.html` in a browser. The token/asset paths inside expect the original project layout (`_ds/...`, `./assets/...`), so if a stylesheet 404s, point the `<link>` tags at `../tokens/` and `../assets/` in this bundle.
