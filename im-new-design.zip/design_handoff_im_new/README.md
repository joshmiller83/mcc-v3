# Handoff: `/im-new` — Get Involved at MCC

**Route:** `/im-new` → `/page/11` (Canvas page, label "I'm New")
**Audit score:** 24/100, "Needs redesign"
**Nature of the work:** this is a **bug fix plus a component-level cleanup**, not a
redesign. The content is right, the copy is approved, the components exist. One
structural rendering bug is producing most of the 24-point score. Fix that first
and re-run the audit before touching anything else.

---

## Revision note

The reference render in this bundle is post-review. Three defects found in the
prototype during design QA were fixed, and each one is now documented in the
section it affects because **the implementer would otherwise reproduce it**:

- Header nav and CTA labels breaking mid-phrase, then the opposite failure — the
  CTA overflowing the right gutter once the wrap was prevented. Both are the same
  flex-sizing problem; see §6, which now specifies the full set of properties and
  recommends raising the mobile-menu breakpoint instead.
- The footer's Visit and Contact columns rendering the street address, service
  times, email, and phone as anchors. Only six items in the footer are real links;
  see §6.

None of these exist in the current Drupal page — they were introduced in the
prototype. They are recorded here so the fixes travel with the spec.

---

## TL;DR — do these in order

1. **Fix `caresphere_theme:section` so it renders its children.** It currently
   outputs an empty `<section>` and the content follows it as a sibling. This is
   the root cause of the empty bands, the invisible hero, and the broken grids.
   (§1)
2. **Turn off Twig debug** on this environment. Every component is wrapped in
   `THEME DEBUG` comments in the delivered HTML. (§2)
3. **Fix `card-icon`** — it renders `aspect-square rounded-none`, which violates
   the design system's 10px radius and makes the cards enormous. (§3)
4. **Wrap loose `accordion__item`s in an `.accordion` parent** and give them a
   44px-minimum trigger. (§4)
5. **Contrast pass** on the newsletter band. (§5)
6. **Tap-target pass** on nav, footer, and card CTA links — 24 targets are under
   44×44. (§6)

Expect the score to move from 24 into the 80s on step 1 alone, because 5 of the 7
contrast failures are a *symptom* of it, not independent problems.

---

## The design reference

`MCC Im New.dc.html` in this bundle is the **target render** — an HTML prototype of
what the page should look like once the above is fixed. It is a design reference,
not production code: do not copy it into the theme. Open it directly in a browser
and compare against `audit/drupal-im-new-desktop.png`.

Its purpose is to settle the questions the broken page can't answer: what colour
each band is, where the section padding lands, how the three serve-cards sit in a
row, and what the FAQ looks like open. Every value in it comes from
`mcc_theme/css/tokens/` — use the token variable, never the literal.

`support.js`, `_ds/`, and `assets/` are prototype runtime and reference copies.
Do not port them; the theme already has the real tokens and the real logo files.

---

## 1. The root cause: `section` renders no children

### What the delivered HTML actually does

Read `audit/im-new-source.html`. Every one of the eight `caresphere_theme:section`
components comes out like this — opening tag, whitespace, closing tag:

```html
<section data-component-id="caresphere_theme:section"
         class="section-layout bg-black section-layout--align-center"
         style="--section-mt: 0rem; --section-mb: 5rem; --section-pt: 7rem; --section-pb: 7rem; --section-gap: 0rem;">

</section>
<!-- 🥨 Component end: caresphere_theme:section -->
<!-- 🥴 Component start: caresphere_theme:section-intro -->
<div class="section-intro section-intro--centered section-intro--text-light ...">
```

The `section-intro` that belongs *inside* that section is emitted **after** its
closing tag. Same for the grids, the cards, the buttons, and the accordions. All
25 components in `component-map.json` render as flat siblings of one another.

### Every audit failure this explains

| Symptom in the audit / screenshots | Why |
|---|---|
| Four tall empty bands (2× `bg-black`, 1× `bg-gray-light`, 1× `bg-white`) | Empty `<section>` with `--section-pt: 7rem; --section-pb: 7rem` — 224px of padding around nothing |
| "Get Involved at MCC", "Serve & Connect", and the hero description at **contrast ratio 1.0** | `section-intro--text-light` renders white text, but it fell out of its `bg-black` section onto the white page background. **The entire hero is invisible.** Same for "Still Have Questions?" and its description. That is 5 of the 7 contrast failures. |
| Three serve-cards stacked full-width instead of 3-up | The `section-grid--layout-3_column` wrapper renders with three *empty* `section-grid__col` divs; the cards land outside it and have no grid to sit in |
| Card description at **96.9 chars per line** | Direct consequence — the card is full page width instead of one third |
| "Browse ministries" / "Meet our leaders" / "Contact us" flush left at the page edge | Their section carried `section-layout--align-center` + `custom-container` + `--section-gap: 1.5rem`; the buttons never entered it |
| Accordion items with no container, no card styling, no exclusive-open behaviour | Same — no `.accordion` parent rendered |
| No section padding anywhere around real content | All of it is on the empty siblings |

### Where to look

`themes/contrib/caresphere_theme/components/section/section.html.twig` (and the
same pattern in `section-grid`). The template is rendering its wrapper but not its
slot content. In Canvas SDCs the child component tree arrives as a slot — most
likely the template is missing the slot print entirely, or printing a variable
that was renamed. Check against a page where sections *do* nest correctly (compare
with the homepage build) to see which variable name the working version uses.

Two things to confirm while you're in there:

- `section-grid` has the same problem — `section-grid__col` divs render empty. Fix
  both; a fix to `section` alone will leave the cards ungridded.
- `section` and `section-grid` are `caresphere_theme` (contrib) components. If you
  cannot patch contrib, override them in `mcc_theme` and document the override —
  do not work around it by hard-coding backgrounds onto `section-intro`.

### Acceptance test

After the fix, `audit/im-new-source.html` regenerated should show `section-intro`
*inside* `<section class="... bg-black ...">`, and the audit's `contrast.fails`
should drop from 7 to at most 2 (the newsletter band, §5).

---

## 2. Twig debug is on

`report.md` flags it: `Twig debug comments detected: yes`. The page ships
`<!-- THEME DEBUG -->`, `FILE NAME SUGGESTIONS`, and the emoji component markers
to every visitor. Set `twig.config.debug: false` in
`sites/default/services.yml` for this environment and rebuild cache. Keep it on
locally.

---

## 3. `card-icon` violates the design system

Current classes on all three cards:

```
card-icon relative p-6 md:p-8 bg-white text-foreground
transition duration-300 hover:bg-neutral-50/80 aspect-square rounded-none
```

Four problems:

- **`rounded-none`** — the design system specifies `--radius-md` (10px) for cards.
  Nothing in this brand is 0px. Set `border-radius: var(--radius-md)`.
- **`aspect-square`** — forces each card to be as tall as it is wide. At full width
  (because of §1) that is why the cards are enormous. Drop it; let content set the
  height and use `align-items: stretch` on the grid so the three stay equal.
- **No border.** The design system's card is `1px solid var(--border-default)` with
  `--shadow-md` on hover only. `hover:bg-neutral-50/80` is not the specified hover.
- **`duration-300`** — the brand's motion token is `--duration-fast` (120ms).

Also fix the card content itself:

- **All three icons are the same generic Lucide globe.** Give each a distinct,
  meaningful icon. The reference uses `hand-heart` (Volunteer on Sundays),
  `heart-handshake` (C.A.R.E. Ministry), `globe` (Support Missions) — Lucide is
  already the theme's established set.
- **Card 1 has no CTA and a link to nowhere.** "Volunteer on Sundays" renders
  `<a href="" class="card-icon__link">` as a full-bleed overlay covering the whole
  card — an empty `href` resolves to the current page, so clicking anywhere on that
  card silently reloads `/im-new`. Either give it a real `cta_url` (the reference
  adds "Volunteer roles →") or remove the overlay link. Do not ship an empty
  `href`.
- **Icon placement.** `icon_align`/`text_align` are set to `left` on all three; the
  reference keeps left-aligned content with the icon in a 52px
  `--color-primary-subtle` tile above the heading. That reads better than a bare
  stroke icon and matches the homepage's pillar cards.

---

## 4. Accordions

The four `accordion__item`s render as loose siblings — no `.accordion` wrapper, no
card container. Consequences: no border/radius, no dividers, and no group
behaviour (opening one does not close the others; each item is independently
toggled by its own `data-accordion-trigger`).

- Wrap the set in the component's `.accordion` container so the items become a
  bordered stack.
- Confirm whether the intended behaviour is exclusive (one open at a time) or
  independent. **Recommend exclusive** — it is a 4-item FAQ, and exclusive keeps
  the page from growing unpredictably. The reference implements exclusive.
- **Trigger height is 27px.** Give the trigger `min-height: 60px` and
  `padding: var(--space-4) var(--space-6)` so the whole row is the hit target.
- The `accordion__close` button is a second, redundant control with
  `tabindex="-1"` sitting next to the trigger. Drop it; use a single trigger with a
  `+` / `−` affordance on the right (the reference uses a 28px
  `--color-primary-subtle` pill).
- Constrain the answer to `max-width: 66ch` — at full container width the answers
  will hit the same 96-char line-length problem the cards did.
- Keep `aria-expanded` on the trigger and `aria-controls`/`role="region"` on the
  panel; the existing markup gets this right.

---

## 5. Newsletter band contrast

`mcc-newsletter-band` fails independently of §1 — "Stay connected" and its body
copy both measure **1.28**. That is white-ish text on the band's own background,
not a fallout of the section bug, so it needs a real fix: either lighten the text
to full `#fff` (no opacity reduction) or darken the band.

The reference folds the newsletter into the walnut footer band (matching the
homepage), with the heading and body at full white and no `opacity` on either.
Reducing opacity on text over a mid-tone background is what produced the 1.28.
If the band stays standalone, put it on `--green-900` and keep the text at full
opacity.

The email input inside it also needs a visible border against the band —
`1px solid rgba(255,255,255,.4)` — and the Subscribe button needs 48px height
(§6).

---

## 6. Tap targets — 24 under 44×44

Full list is in `audit.json` under `tapTargets.smallTargets`. Grouped by fix:

- **Primary nav links, 22–28px tall.** Give `.menu__link` `display: flex;
  align-items: center; min-height: 44px; padding: 0 10px; white-space: nowrap`,
  and reduce the header's vertical padding to compensate so the bar height doesn't
  grow. Keep the active item's `--color-secondary` 2px bottom border.

  Two constraints come with this and they interact — get both or the header breaks.
  The header is a `space-between` flex row and the logo is ~275px wide:

  - `white-space: nowrap` on the links and the CTA is **required**, or they shrink
    below their content width and break mid-phrase ("I'm / New", "Get / Involved").
  - But `flex: none` on the `<nav>` *and* the CTA makes the row unshrinkable, and
    below ~940px the excess spills past the right gutter — the CTA ends up flush to
    the viewport edge while every other section keeps its `--space-6` gutter. No
    scrollbar appears, so it is easy to miss in review.

  The reference resolves it by making the row fit rather than forcing it: nav link
  padding `0 10px`, header `gap: var(--space-4)`, nav internal
  `gap: var(--space-1)`, `flex: none` on the nav and the CTA, and the logo anchor
  set to `flex: 0 1 auto; min-width: 0` with `max-width: 100%` on the image so the
  logo is the one element that gives.

  **Better answer for production:** raise the mobile-menu breakpoint (§9) to ~940px
  so the nav collapses into the existing `.mobile-menu-toggle` before it can
  collide at all. The theme already has the toggle; it is currently only wired for
  narrow phones.
- **Footer links, 24px tall** (7 of them). Same treatment: `min-height: 44px`,
  flex-centered, and drop the `gap` on the column since the padding now provides
  the rhythm. Apply this **only to the six real links** that `audit.json`
  enumerates (I'm New, Contact, Sermons, Calendar, Ministries, Get Involved) — the
  address, service times, email, and phone in the Visit and Contact columns are
  plain text, not anchors. Don't wire an address up as a link.
- **Card CTA links ("Learn More", "Our Missions"), 24px tall.** `min-height: 44px`
  on `.button--link`, with `margin-top: auto` so the CTA pins to the card bottom
  and all three cards' CTAs align.
- **Accordion triggers, 27px** — covered in §4.
- **`Get Involved` header button, 39px** and the two ministry buttons — bump to 44
  and 48 respectively.
- **Skip link at 1×1px** is intentional (`.visually-hidden.focusable`) and correct.
  Exclude it from the audit rather than "fixing" it.
- **Logo link at 262×40** — give the `<a>` `min-height: 44px` and flex-center the
  image inside; don't scale the logo.

---

## 7. Colour and band rhythm (design decisions to apply)

Once sections nest properly you have to decide what each band actually is. The
current inputs give you `bg-black`, `bg-white`, `bg-gray-light`, `bg-white`,
`bg-black` — five bands, two of them "black", which in this theme renders as near
walnut. That's too much dark for a welcome page, and `bg-black` is not a brand
colour.

Recommended, as built in the reference:

| Section | Background | Text |
|---|---|---|
| Hero — "Get Involved at MCC" | `--green-900` | `--text-on-inverse` |
| "Ways to Serve" + cards | `--surface-page` (oatmeal) | `--text-body` |
| "Find Your Ministry" | `--neutral-50`, hairline top and bottom | `--text-body` |
| "Common Questions" | `--surface-page` | `--text-body` |
| "Still Have Questions?" | `--terracotta-900` | `--text-on-inverse` |
| Footer + newsletter | `--walnut-900` + oak texture | `#fff` |

That is two dark bands, top and bottom, framing the light middle — and it honours
the design system's "max 1–2 background colours per page" rule. **Replace
`bg-black` with the green and terracotta tokens**; if `bg-black` is the only
available `backgroundcolor` option on the `section` SDC, add the brand values as
options rather than shipping black.

Section padding: `var(--space-20)` top and bottom (the current 7rem ≈ `--space-28`
is heavier than the rest of the site). Remove the `--section-mb: 5rem` on sections
whose padding already separates them — right now you get padding *and* margin
stacking between bands.

---

## 8. Content and structure notes

- **The hero has `section-intro--has-ctas` with an empty actions container.** Either
  give the hero a real CTA or drop the modifier. An empty `section-intro__actions`
  div renders on four of the five section-intros on this page.
- **`h1` then four `h2`s** — heading order is correct. Keep the h1 on the hero only.
- **Copy is approved as-is.** Only two changes in the reference, both minor: "Yes!"
  → "Yes." in the youth FAQ answer (the brand voice guide caps exclamation points
  at genuine warmth, and "We Love People!" already spends it), and card CTAs
  normalised to sentence case ("Learn more", "Our missions") per the same guide.
  Confirm with the church before applying.
- **`/node/35`** is the C.A.R.E. Ministry CTA target. Replace with the path alias
  before launch; raw node paths in content are a maintenance trap.

---

## 9. Responsive

Not represented in `audit.json` beyond the mobile screenshot, which shows the same
structural bug. Specify at implementation:

- Serve cards: 3-up → 2-up ≤ 900px → 1-up ≤ 600px.
- Hero `h1`: 52px → 38px ≤ 700px.
- Section padding: `--space-20` → `--space-12` ≤ 700px.
- Footer columns: 4-col grid → 2-col ≤ 900px → 1-col ≤ 600px.
- Nav collapses to the existing `.mobile-menu-toggle` — that part already works.
- Buttons in "Find Your Ministry" and "Still Have Questions?" go full-width below
  480px (`mobile_width` is already an input on the `button` SDC — use it).

---

## Design tokens

All already defined in `mcc_theme/css/tokens/`. Use the variable, not the literal.

**Colour** — `--color-primary` (`#2f4833`), `--color-primary-subtle`, `--green-700`,
`--green-800`, `--green-900`, `--color-secondary` (`#ae5b33`), `--terracotta-700`,
`--terracotta-900`, `--walnut-900` (`#4e3426`), `--oatmeal` (`#e9e3d5`),
`--surface-page`, `--surface-card`, `--neutral-50`, `--text-body`, `--text-muted`,
`--text-on-primary`, `--text-on-inverse`, `--text-link`, `--text-link-hover`,
`--border-subtle`, `--border-default`, `--border-strong`.

**Type** — `--font-display` (Calistoga, weight 400 only) for the `h1`, section
headings, and card headings. `--font-body` (Nunito) for everything else. Weights
`--fw-medium` / `--fw-bold`. Eyebrows are 13px `--fw-bold`,
`letter-spacing: var(--tracking-eyebrow)`, uppercase, `--color-secondary`.
Sizes used: 52 / 40 / 36 / 22 / 19 / 17 / 16 / 15 / 14 / 13px.

**Spacing** — the scale is `--space-1..6, 8, 10, 12, 16, 20, 24, 32`. **There is no
`--space-7`, `--space-9`, `--space-11`, or `--space-14`.** Referencing one silently
kills the whole declaration, which is easy to miss in review.

**Radius** — `--radius-sm` 6px (inputs), `--radius-md` 10px (cards, buttons),
`--radius-pill` 999px (chips, the FAQ +/− affordance).

**Shadow** — `--shadow-md` on card hover only. No resting shadow on these cards.

**Motion** — `--duration-fast` 120ms, `--ease-standard` `cubic-bezier(.4,0,.2,1)`.
No entrance animations, no scroll choreography.

---

## Files in this bundle

- `MCC Im New.dc.html` — the target render. Open directly in a browser. Tweakable:
  `openFirstFaq`.
- `audit/im-new-source.html` — the delivered Drupal HTML. **Read this first**; §1
  is visible in it directly.
- `audit/component-map.json` — the 25 Canvas components with their inputs and
  content values. Use it to confirm the content is correct before changing any of
  it.
- `audit/audit.json` — the raw contrast / line-length / tap-target measurements.
  Re-run after step 1 before working through §3–§6.
- `audit/drupal-im-new-desktop.png`, `audit/drupal-im-new-mobile.png` — the broken
  state, for comparison.
- `support.js`, `_ds/`, `assets/` — prototype runtime and reference copies. Not
  part of the design. Do not port; the theme has the real tokens and logos.
